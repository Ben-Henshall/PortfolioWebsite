package datarepresentation;

/**
 * Thrown to indicate that there has been an attempt to add an element to an already 
 * full row of data or an attempt to add a row of data too large for the container.
 * @author PAIDIA
 */
public class RowOverflowException extends RuntimeException {

    public RowOverflowException(){}
    
    public RowOverflowException(String message){
        super(message);
    }
    
}
