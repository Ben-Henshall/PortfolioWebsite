package datarepresentation;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 * JTable wrapper class which adds compatibility with the TableObject data 
 * structure and increased validation procedures.
 * @author PAIDIA
 */
public class PaidiaTable{
    
    private DefaultTableModel dtm;
    private JTable jt;
    private final int columnCount;
    
    /**
     * Creates a PaidiaTable with header names but no rows.
     * The number of header names passed corresponds to the maximum number of 
     * columns in the object. This size is immutable.
     * @param headers Header names.
     */
    public PaidiaTable(String[] headers){
        dtm = new DefaultTableModel(headers, 0);
        jt = new JTable(dtm);
        columnCount = headers.length;
    }
    
    /**
     * Returns the underlying JTable instance.
     * @return The underlying JTable instance.
     */
    public JTable getJTable(){
        return jt;
    }
 
    /**
     * Adds a row of data to the table. Validates input to ensure the input is 
     * of correct length.
     * @param data The row to be added to the table.
     */
    public void addRow(TableObject data){
        if(data.getSizeLimit() > columnCount){
            throw new RowOverflowException();
        }
        else{
            dtm.addRow(data.getStringArray());
        }
    }
    
    /**
     * Removes the row of data which has been selected from the GUI.
     */
    public void deleteSelectedRow(){
        dtm.removeRow(jt.getSelectedRow());
    }
    
}
