package api;

import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.NodeList;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

/**
 * Class containing a set of navigational information actions relating to a central 
 * user location. Provides step-by-step directional information along with 
 * associated metrics. Can generate visual maps based upon the locations it serves 
 * for integration into Swing applications.
 * @author Mike Green - 200922076
 */
public class LocationManager {
    
    final private static String RESPONSE_PATH = "response.xml";
    
    // Public constants (URL starters)
    final public static String DISTANCE_MATRIX_START = "https://maps.googleapis.com/maps/api/distancematrix/xml?";
    final public static String STATIC_MAP_START = "https://maps.googleapis.com/maps/api/staticmap?";
    final public static String DIRECTIONS_START = "https://maps.googleapis.com/maps/api/directions/xml?";
    
    // Google API keys
    final private static String API_KEY_BROWSER = "AIzaSyCYw2qs8SFEMd5INZOie1zKA5IeXIlIBO8";
    final private static String API_KEY_SERVER = "AIzaSyAtJOoUhCM89Kba4p0Q2wBCaYOFulIkbec";
    
    // Tranport modes enum
    public enum TransportMode {
        DRIVING, WALKING, BICYCLING, TRANSIT;
    }
    
    // Instance variables
    private String userLocation;

    
    /* Instances of the class only required if a function requires a user 
     * location otherwise, static methods are sufficient
     */
    
    /**
     * Creates an instance of LocationManager where the associated userLocation 
     * is null.
     */
    public LocationManager(){
        userLocation = null;
    }
    
    
    /**
     * Creates an instance of LocationManager with a set userLocation.
     * @param location The user's location.
     */
    public LocationManager(String location){
        userLocation = normaliseString(location);
    }
    
    
    /**
     * Sets the userLocation variable to that of the parameter value.
     * @param newLocation Location to replace the old userLocation value.
     */
    public void setUserLocation(String newLocation) {
        userLocation = newLocation;
    }

    /**
     * Returns the userLocation as held by the LocationManager.
     * @return the userLocation as held by the LocationManager.
     */
    public String getUserLocation() {
        return userLocation;
    }
    
    
    /**
     * Normalises a String to the format required by Google's API.
     * @param sample The unnormalised String.
     * @return A normalised version of <code>sample</code>.
     */
    private static String normaliseString(String sample){
       sample = sample.replaceAll(" ", "+");
       return sample;
    }
    
    
    /**
     * Given parameters for centre, zoom and size, JLabel containing a static map 
     * of a location generated.
     * @param centre Centre point of map in plain text.
     * @param zoom Level of zoom displayed.
     * @param size Dimensions of the map, in pixels.
     * @return JLabel holding the map image.
     * @throws MalformedURLException Thrown if generated map URL is invalid.
     */
    public static JLabel getMap(String centre, int zoom, Dimension size) throws MalformedURLException{
        String path = STATIC_MAP_START;
        centre = normaliseString(centre);
        path = addParameter(path, "center", centre);
        path = addParameter(path, "zoom", Integer.toString(zoom));
        path = addParameter(path, "size", (int)size.getWidth() + "x" + (int)size.getHeight());
        path = addParameter(path, "markers", centre);
        URL url = new URL(path);
        BufferedImage image = null;
        try {
            image = ImageIO.read(url);
        } catch (IOException ex) {
            System.err.println("Error accessing map image.\n\n"
                        + ex.getMessage());
        }
       return new JLabel(new ImageIcon(image));
    }
    
    
    
    /**
     * Calculates the distance from the user's location to the destination in km.
     * @param destination The name of the destination.
     * @return The numerical distance from the user's location to the destination.
     * @throws java.io.IOException Thrown if issues encountered when 
     * establishing a connection to external server.
     */
    public double distanceTo(String destination) throws IOException{
        // Generate request
        String request = DISTANCE_MATRIX_START;
        request = addParameter(request, "origins", normaliseString(getUserLocation()));
        request = addParameter(request, "destinations", normaliseString(destination));
        request = addParameter(request, "key", API_KEY_SERVER);
        request = addParameter(request, "units", "metric");
        
        
        // Send request
        try {
            sendRequest(request, RESPONSE_PATH);
        } catch (MalformedURLException ex) {
            System.err.println("Invalid distance request submitted.\n\n"
                        + ex.getMessage());
        }
        
        
        // Parse response
        File responseFile = new File(RESPONSE_PATH);
	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	DocumentBuilder builder = null;
        try {
            builder = factory.newDocumentBuilder();
        } catch (ParserConfigurationException ex) {
            System.err.println("Parser failed to initialise.\n\n"
                        + ex.getMessage());
        }
        
	Document doc = null;
        try {
            doc = (Document) builder.parse(responseFile);
        } catch (SAXException ex) {
            System.err.println("Invalid XML response from server.\n\n"
                        + ex.getMessage());
        }
        doc.getDocumentElement().normalize();   // Should already be normalised
        
        // Create node list with each node being a "distance"
        NodeList nodes = doc.getElementsByTagName("distance");

        // Scan node list, extract distance values
        String distanceString[] = new String[nodes.getLength()];
        for (int i = 0; i < nodes.getLength(); i++) {
            Node currentNode = nodes.item(i);
            if (currentNode.getNodeType() == Node.ELEMENT_NODE) {   // if node is an element
                Element currentElement = (Element) currentNode;
                distanceString[i] = currentElement.getElementsByTagName("text").item(0).getTextContent();
            }
	}
        
        // Strip excess and return distance value
        if (distanceString[0].endsWith(" km")) {
            distanceString[0] = distanceString[0].substring(
                    0, distanceString[0].length() - 3);
        }
        return Double.valueOf(distanceString[0]);
    }
    
    
    
    
    /**
     * Generates a set of travel information via the requested transport mode to 
     * the desired destination.
     * @param destination The destination for the directions.
     * @param mode The mode of transport to be used.
     * @return A set of directions and associated information including distance, 
     * distance and (if applicable) bus numbers for each.
     * @throws IOException Thrown if issues encountered when 
     * establishing a connection to external server.
     */
    public DirectionSet directionsTo(String destination, TransportMode mode) throws IOException{
        // Generate request
        String request = DIRECTIONS_START;
        request = addParameter(request, "origin", getUserLocation());
        request = addParameter(request, "destination", destination);
        request = addParameter(request, "key", API_KEY_SERVER);
        request = addParameter(request, "units", "metric");
        request = addParameter(request, "markers", "color:red%7Clabel:A%7C" + destination);
        // Convert mode to string
        switch(mode){
            case DRIVING:
                request = addParameter(request, "mode", "driving");
                break;
                
            case WALKING:
                request = addParameter(request, "mode", "walking");
                break;
                
            case BICYCLING:
                request = addParameter(request, "mode", "bicycling");
                break;
                
            case TRANSIT:
                request = addParameter(request, "mode", "transit");
                break;
            
            default:
                throw new InvalidParameterException();
        }
        
        // Send request
        try {
            sendRequest(request, RESPONSE_PATH);
        } catch (MalformedURLException ex) {
            System.err.println("Invalid directions request submitted.\n\n"
                        + ex.getMessage());
        }
        
        // Parse response
        File responseFile = new File(RESPONSE_PATH);
	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	DocumentBuilder builder = null;
        try {
            builder = factory.newDocumentBuilder();
        } catch (ParserConfigurationException ex) {
            System.err.println("Parser failed to initialise.\n\n"
                        + ex.getMessage());
        }
        
	Document doc = null;
        try {
            doc = (Document) builder.parse(responseFile);
        } catch (SAXException ex) {
            System.err.println("Invalid XML response from server.\n\n"
                        + ex.getMessage());
        }
        doc.getDocumentElement().normalize();   // Should already be normalised
        
        
        // Create node list with each node being a "step"
        NodeList steps = doc.getElementsByTagName("step");
        // Result arrays
        String instructions[] = new String[steps.getLength()];
        String distance[] = new String[steps.getLength()];
        String duration[] = new String[steps.getLength()];
        String transitNumber[] = new String[steps.getLength()];
        
        Element currentStepElement, currentDistanceElement, 
                currentDurationElement, currentTransitNumberElement, busElement;
        String currentInstructionElement;
        // Scan steps list, extract data
        for (int i = 0; i < steps.getLength(); i++) {   // for each step
            Node currentStepNode = steps.item(i);
            if (currentStepNode.getNodeType() == Node.ELEMENT_NODE) {   // if step node is an element
                // Decode step
                currentStepElement = (Element) currentStepNode;
                try{
                    currentInstructionElement = currentStepElement.getElementsByTagName("html_instructions").item(0).getTextContent();
                } catch (NullPointerException ex){
                    continue;
                }
                //If try-catch not triggered, continue with assignment
                instructions[i] = currentInstructionElement;
                
                 // Regex, remove all HTML formatting and all div content entirely
                instructions[i] = instructions[i].replaceAll("(<div.*?div>)|(<.*?>)", "");
                
                // Decode distance
                currentDistanceElement = (Element) currentStepElement.getElementsByTagName("distance").item(0);
                distance[i] = currentDistanceElement.getElementsByTagName("text").item(0).getTextContent();
                
                // Decode duration
                currentDurationElement = (Element) currentStepElement.getElementsByTagName("duration").item(0);
                duration[i] = currentDurationElement.getElementsByTagName("text").item(0).getTextContent();
                
                // Decode bus number (if applicable)
                if(mode == TransportMode.TRANSIT){
                    try{
                        currentTransitNumberElement = (Element) currentStepElement.getElementsByTagName("transit_details").item(0);
                        currentTransitNumberElement = (Element) currentTransitNumberElement.getElementsByTagName("line").item(0);
                        // test if bus
                        busElement = (Element) currentTransitNumberElement.getElementsByTagName("vehicle").item(0);
                        busElement = (Element) busElement.getElementsByTagName("type").item(0);
                        if(busElement.getTextContent().equals("BUS")){
                            transitNumber[i] = currentTransitNumberElement.getElementsByTagName("short_name").item(0).getTextContent();
                        }
                        else{
                            transitNumber[i] = null;
                        }
                    } catch(NullPointerException ex){
                        transitNumber[i] = null;
                    }
                }
                else{
                    transitNumber[i] = null;
                }
                    
                }
	}
        
        
        // Remove full null directions sent by server
        List<String> instructionsList = new ArrayList<>(Arrays.asList(instructions));
        List<String> distanceList = new ArrayList<>(Arrays.asList(distance));
        List<String> durationList = new ArrayList<>(Arrays.asList(duration));
        List<String> transitNumberList = new ArrayList<>(Arrays.asList(transitNumber));

        int removalCount = 0;
        for(int i = 0; i < instructions.length - removalCount; i++){
            if(instructionsList.get(i) == null){
                instructionsList.remove(i);
                distanceList.remove(i);
                durationList.remove(i);
                transitNumberList.remove(i);
                removalCount++;
            }
        }
        
        Object[] instructionsO = instructionsList.toArray();
        Object[] distanceO = distanceList.toArray();
        Object[] durationO = durationList.toArray();
        Object[] transitNumberO = transitNumberList.toArray();
        
        instructions = Arrays.copyOf(instructionsO, instructionsO.length, String[].class);
        distance = Arrays.copyOf(distanceO, distanceO.length, String[].class);
        duration = Arrays.copyOf(durationO, durationO.length, String[].class);
        transitNumber = Arrays.copyOf(transitNumberO, transitNumberO.length, String[].class);
        
        
        // Encapsulate three arrays together and return.
        DirectionSet directions = new DirectionSet(instructions, distance, duration, transitNumber);
        return directions;
    }
    
    
    
    /**
     * Adds a parameter name and value pair to a base URL string in correct format.
     * @param baseString The string before to have a value pair added to it.
     * @param pName The name of the parameter.
     * @param pValue The value of the parameter.
     * @return The original String with the parameter pair appended.
     */
    public static String addParameter(String baseString, String pName, String pValue){
        char lastChar = baseString.charAt(baseString.length() - 1);
        if(lastChar != '&' && lastChar != '?') baseString = baseString + "&";
        baseString = baseString + normaliseString(pName) + "=" + normaliseString(pValue);
        return baseString;
    }


    /**
     * Given a correctly formatted request URL, this method will execute the request and 
     * store the response in the specified file path.
     * @param requestString HTTP(S) request to be executed.
     * @param responsePath Path to the file to store response from server.
     * @throws MalformedURLException Thrown when an invalid requestString is passed.
     */
    private static void sendRequest(String requestString, String responsePath) throws MalformedURLException{
        
        BufferedReader inputReader = null;
        PrintWriter outputSaver = null;
        try {
            outputSaver = new PrintWriter(responsePath);
        } catch (FileNotFoundException ex) {
           System.err.println("Response file not found.\n\n"
                        + ex.getMessage());
        }
        try{
            // Form the connection for the given request
            URL requestURL = new URL(requestString);
            URLConnection connection = requestURL.openConnection();
            inputReader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String inputLine;
            
            // Write the response to file, line by line
            while ((inputLine = inputReader.readLine()) != null){
                outputSaver.println(inputLine);
            }
            outputSaver.flush();
        }
        catch (IOException ex){
            System.err.println("Error accessing connection to server.\n\n"
                        + ex.getMessage());
        }
        finally{
            try {
                // Close all streams
                outputSaver.close();
                inputReader.close();
            } catch (IOException ex) {
                System.err.println("Error closing response stream from server.\n\n"
                        + ex.getMessage());
            }
        }
        
    }
    
    
    /**
     * An immutable representation of a set of direction steps consisting of 
     * three components; plain-text instructions, distance and duration.
     */
    public class DirectionSet{
        
        final private String[] instructions;
        final private String[] distance;
        final private String[] duration;
        final private String[] transitNumber;
        final private int steps;
        final private int totalDuration;
        final private double totalDistance;

        
        public DirectionSet(String[] inst, String[] dist, String[] dur, String[] trans){
            instructions = inst;
            distance = dist;
            duration = dur;
            transitNumber = trans;
            steps = instructions.length;
            totalDuration = calculateTotalDuration();
            totalDistance = calculateTotalDistance();
        }
        
        public String[] getInstructions() {
            return instructions;
        }

        public String[] getDistance() {
            return distance;
        }

        public String[] getDuration() {
            return duration;
        }        
        
        public String[] getTransitNumber() {
            return transitNumber;
        }
        
        public int getSteps() {
            return steps;
        }
        
        public double getTotalDistance() {
            return totalDistance;
        }
        
        public int getTotalDuration() {
            return totalDuration;
        }
        
        /**
         * Calculates the total duration by summing all duration Strings in 
         * the data structure.
         * @return The sum of all distances as an int, in minutes.
         */
        private int calculateTotalDuration(){
            int total = 0;
            String currentDuration;
            String subStrings[];
            for(int i = 0; i < steps; i++){
                currentDuration = duration[i];

                try{
                    try{
                        if(currentDuration.contains("hour")){   // hours and minutes
                            subStrings = currentDuration.split(" hour ");
                            total += (Integer.valueOf(subStrings[0]) * 60);
                            total += Integer.valueOf(subStrings[1].replaceAll("[^0-9.]", ""));
                        }
                        else{   // just minutes
                            currentDuration = currentDuration.replaceAll("[^0-9.]", "");
                            total += Integer.valueOf(currentDuration);
                        }
                    } catch(NullPointerException ex){
                        
                    }
                } catch(NumberFormatException | NullPointerException ex){
                    continue; // null step, ignore
                }
            }
            return total;
        }
        
        /**
         * Calculates the total distance by summing all distance Strings in 
         * the data structure.
         * @return The sum of all distances as a double, in km.
         */
        private double calculateTotalDistance(){
            double total = 0;
            String currentDistance;
            for(int i = 0; i < steps; i++){
                currentDistance = distance[i];
                
                try{
                    if(currentDistance.endsWith(" km")){
                        currentDistance = currentDistance.replaceAll(" km", "");
                        try{
                            total += Double.valueOf(currentDistance);
                        } catch(NumberFormatException ex){
                            continue;     // null step, ignore
                        }
                    }

                    else if(currentDistance.endsWith(" m")){
                        currentDistance = currentDistance.replaceAll(" m", "");
                        try{
                            total += (Double.valueOf(currentDistance) / 1000.0);
                        } catch(NumberFormatException ex){
                            continue;     // null step, ignore
                        }
                    }
                } catch(NullPointerException ex){
                    
                }
                
            }
            return total;
        }
    }

}
