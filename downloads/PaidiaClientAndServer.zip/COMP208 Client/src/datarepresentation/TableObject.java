package datarepresentation;

import java.util.ArrayList;

/**
 * A representation of a single row of data in a table.
 * To be used in conjunction with a PaidiaTable instance.
 * @author Mike Green - 200922076
 */
@SuppressWarnings("unchecked")
public class TableObject {
    
    private ArrayList row;
    private final int SIZE_LIMIT;  // set in constructor only.
    
    /**
     * Creates a blank TableObject holding no data.
     * @param limit Maximum number of elements permitted to be stored in the object.
     */
    public TableObject(int limit){
        SIZE_LIMIT = limit;
        row = new ArrayList();
    }
    
    /**
     * Creates a TableObject containing the data held in the passed array.
     * Has a maximum size that is the size of the array.
     * @param <T> Comparable data types.
     * @param elementArray Data to populate the TableObject.
     */
    public <T extends Comparable<T>> TableObject(T[] elementArray){
        row = new ArrayList();
        SIZE_LIMIT = elementArray.length;
        addMultipleElements(elementArray);
    }
    
    
    /**
     * Creates a partially completed TableObject containing the data 
     * held in the passed array.
     * Allows for inclusion of data until the specified size limit is reached.
     * @param <T> Comparable data types.
     * @param limit Maximum number of elements permitted to be stored in the object.
     * @param elementArray Data to populate the TableObject.
     */
    public <T extends Comparable<T>> TableObject(int limit, T[] elementArray){
        row = new ArrayList();
        SIZE_LIMIT = limit;
        addMultipleElements(elementArray);
    }
    
    /**
     * Appends an element to the end of the data structure.
     * @param <T> Comparable data types.
     * @param newElement The element to be added.
     */
    public <T extends Comparable<T>> void addElement(T newElement){
        // Accept comparable to enable sorting by elements
        if(row.size() < SIZE_LIMIT){
            row.add(newElement);
        }
        else{
            throw new RowOverflowException();
        }
    }
    
    /**
     * Appends multiple elements to the end of the data structure.
     * Elements added in the order stored in array.
     * @param <T> Comparable data types.
     * @param elementArray The elements to be added.
     */
    public final <T extends Comparable<T>> void addMultipleElements(T[] elementArray){
        for(int i = 0; i < elementArray.length; i++){
            addElement(elementArray[i]);
        }
    }
    
    /**
     * Accessor method for retrieving data stored in the data structure.
     * @param <T> Comparable data types.
     * @param index Position in the data structure to query.
     * @return The element stored at index.
     */
    public <T extends Comparable<T>> T getElement(int index){
        return (T)row.get(index);   // type-cast to T, T guarunteed
    }
    
    
    /**
     * Converts each element of the data structure to a String representation.
     * @return An array where each element is a String representing a corresponding 
     * TableObject element.
     */
    public String[] getStringArray(){
        int size = row.size();
        String[] output = new String[size];
        for(int i = 0; i < size; i++){
            output[i] = row.get(i).toString();
        }
        return output;
    }
    
    
    /**
     * Accessor method returning the maximum size of the TableObject.
     * @return The maximum size of the TableObject instance.
     */
    public int getSizeLimit(){
        return SIZE_LIMIT;
    }
    
    /**
     * Accessor method returning the maximum size of the TableObject.
     * @return The maximum size of the TableObject instance.
     */
    public static String[][] convertStringToArray(String input){
        String[] row = input.split(new Character((char)2).toString());
        int attributeCount = row[0].split(new Character((char)1).toString()).length;
        String[][] array = new String[row.length][attributeCount];
        
        for(int i = 0; i < row.length; i++){
            array[i] = row[i].split(new Character((char)1).toString());
        }
         return array;
    }
    
}
