package gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author Ben
 */
public class AddAdminDialog extends JDialog {

    JTextField usernameTextBox;
    JTextField passwordTextBox;
    JTextField password2TextBox;
    JComboBox clearanceCombo;
    JLabel usernameLabel;
    JLabel passwordLabel;
    JLabel password2Label;
    JLabel clearanceLabel;
    JButton submitButton;
    JButton exitButton;
    JFrame parent;
    String buttonPressed;
    String originalName;
    String[][] result;
    String id;

    public AddAdminDialog(JFrame p, String b, String idPass) {
        super(p, true);
        setLayout(new GridBagLayout());
        parent = p;
        setSize(350, 200);
        setResizable(false);
        buttonPressed = b;
        if (buttonPressed.equals("addAdmin")) {
            setTitle("Add Admin");
        } else {
            setTitle("Edit Admin");
        }
        id = idPass;

        GridBagConstraints c = new GridBagConstraints();
        usernameLabel = new JLabel();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 0;
        add(usernameLabel, c);

        c = new GridBagConstraints();
        usernameTextBox = new JTextField();
        usernameTextBox.setDocument(new JTextFieldLimit(20));
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 0;
        add(usernameTextBox, c);
        if (buttonPressed.equals("addAdmin")) {
            c = new GridBagConstraints();
            passwordLabel = new JLabel("Enter Password:");
            c.fill = GridBagConstraints.HORIZONTAL;
            c.insets = new Insets(10, 40, 0, 0);
            c.weightx = 0;
            c.gridx = 0;
            c.gridy = 1;
            add(passwordLabel, c);

            c = new GridBagConstraints();
            passwordTextBox = new JTextField();
            passwordTextBox.setDocument(new JTextFieldLimit(50));
            c.fill = GridBagConstraints.HORIZONTAL;
            c.insets = new Insets(10, 10, 0, 40);
            c.weightx = 0.5;
            c.gridx = 1;
            c.gridy = 1;
            add(passwordTextBox, c);

            c = new GridBagConstraints();
            password2Label = new JLabel("Re-enter Password:");
            c.fill = GridBagConstraints.HORIZONTAL;
            c.insets = new Insets(10, 40, 0, 0);
            c.weightx = 0;
            c.gridx = 0;
            c.gridy = 2;
            add(password2Label, c);

            c = new GridBagConstraints();
            password2TextBox = new JTextField();
            password2TextBox.setDocument(new JTextFieldLimit(50));
            c.fill = GridBagConstraints.HORIZONTAL;
            c.insets = new Insets(10, 10, 0, 40);
            c.weightx = 0.5;
            c.gridx = 1;
            c.gridy = 2;
            add(password2TextBox, c);
        }

        c = new GridBagConstraints();
        clearanceLabel = new JLabel("Clearance level:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 3;
        add(clearanceLabel, c);

        c = new GridBagConstraints();
        clearanceCombo = new JComboBox();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 3;
        clearanceCombo.addItem("1");
        clearanceCombo.addItem("2");
        clearanceCombo.addItem("3");
        add(clearanceCombo, c);

        c = new GridBagConstraints();
        submitButton = new JButton();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(20, 60, 0, 40);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 4;
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                submit();
            }
        });
        add(submitButton, c);

        c = new GridBagConstraints();
        exitButton = new JButton("Exit");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(20, 40, 0, 60);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 4;
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exitDialog();
            }
        });
        add(exitButton, c);

        if (buttonPressed.equals("editAdmin")) {
            usernameLabel.setText("Username:");
            usernameTextBox.setEnabled(false);
            submitButton.setText("Confirm");
        } else {
            usernameLabel.setText("Select a username:");
            passwordLabel.setText("Select a password:");
            submitButton.setText("Create");
        }

        if (!id.equals("")) {
            result = PaidiaClient.getSpecificAdmin(id);

            if (result != null) {
                usernameTextBox.setText(result[0][1]);
                clearanceCombo.setSelectedItem(result[0][3]);
            }
        }
        this.getRootPane().setDefaultButton(submitButton);

    }

    void submit() {
        if (usernameTextBox.getText().contains("'")) {
            usernameTextBox.setText(usernameTextBox.getText().replace("'", ""));
        }
        if (buttonPressed.equals("addAdmin")) {
            if (passwordTextBox.getText().contains("'")
                    || password2TextBox.getText().contains("'")) {
                passwordTextBox.setText(passwordTextBox.getText().replace("'", ""));
                password2TextBox.setText(password2TextBox.getText().replace("'", ""));
            }
        }
        boolean usernameTaken = false;
        if (buttonPressed.equals("addAdmin")) {
            if (!passwordTextBox.getText().equals("") && !password2TextBox.getText().equals("") && !usernameTextBox.getText().equals("")) {
                if (passwordTextBox.getText().equals(password2TextBox.getText())) {
                    if (!usernameTextBox.getText().equals(passwordTextBox.getText())) {
                        String[][] result = PaidiaClient.getAllAdmins();
                        for (int i = 0; i < result.length; i++) {
                            if (result[i][1].equals(usernameTextBox.getText())) {
                                JOptionPane.showMessageDialog(null, "Username already taken", "ERROR", JOptionPane.ERROR_MESSAGE);
                                usernameTaken = true;
                                break;
                            }
                        }
                        if (usernameTaken == false) {
                            PaidiaClient.addAdmin(usernameTextBox.getText(), passwordTextBox.getText(), clearanceCombo.getSelectedItem().toString());
                            dispose();
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Username and password cannot be the same", "ERROR", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Passwords do not match", "ERROR", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Please enter all fields", "ERROR", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            if (!usernameTextBox.getText().equals("")) {
                    PaidiaClient.promoteAdmin(id, clearanceCombo.getSelectedItem().toString());
                    dispose();
            } else {
                JOptionPane.showMessageDialog(null, "Please enter a username", "ERROR", JOptionPane.ERROR_MESSAGE);
            }
        }
        PaidiaClient.refreshAdmins();
        
    }

    void exitDialog() {
        PaidiaClient.refreshAdmins();
        dispose();
    }
}