package gui;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Dimension;
import javax.swing.BoxLayout;
import javax.swing.JPanel;

class ActorCard extends JPanel {

    final static int navigationPanelWidth = 175;

    private JPanel navigationPanel;
    private JPanel sideBarPanel;
    private JPanel switchPanel;
    private JPanel contentPanel;
    private CardLayout contentLayout;

    public ActorCard(JPanel[] contentCard) {
        setLayout(new BorderLayout());
        sideBarPanel = new JPanel();
        sideBarPanel.setLayout(new BorderLayout());
        navigationPanel = new JPanel();
        navigationPanel.setLayout(new BoxLayout(navigationPanel, BoxLayout.Y_AXIS));
        navigationPanel.setPreferredSize(new Dimension(navigationPanelWidth, 1));
        switchPanel = new JPanel();
        //switchPanel.setLayout(new BorderLayout());
        contentPanel = new JPanel();
        contentLayout = new CardLayout();
        contentPanel.setLayout(contentLayout);
        for (int i = 0; i < contentCard.length; i++) {
            contentPanel.add(contentCard[i], Integer.toString(i + 1));
        }

        add(BorderLayout.WEST, sideBarPanel);
        sideBarPanel.add(BorderLayout.CENTER, navigationPanel);
        add(BorderLayout.CENTER, contentPanel);
        sideBarPanel.add(BorderLayout.SOUTH, switchPanel);

    }

    public JPanel getNavigationPanel() {
        return navigationPanel;
    }

    public JPanel getSwitchPanel() {
        return switchPanel;
    }

    public JPanel getContentPanel() {
        return contentPanel;
    }

    public CardLayout getContentLayout() {
        return contentLayout;
    }

}
