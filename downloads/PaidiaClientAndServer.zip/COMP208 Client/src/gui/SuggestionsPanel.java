package gui;

import datarepresentation.PaidiaTable;
import datarepresentation.TableObject;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 *
 * @author Ben
 */
public class SuggestionsPanel extends JPanel {

    final String[] HEADERS = {"ID", "Name", "Activity Type", "Opening Hours", "Cost", "Minimum participants", "Telephone No.", "Website", "Address 1",
        "Address 2", "Postcode", "Town/city", "County", "Email", "Description"};

    JButton viewButton;
    JButton approveButton;
    JButton denyButton;
    JFrame frame;
    boolean isClient;
    int tableWidth;
    PaidiaTable suggestionsTable;
    JScrollPane pane;

    public SuggestionsPanel(JFrame j, boolean b) {
        frame = j;
        isClient = b;

        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.fill = GridBagConstraints.HORIZONTAL;
        c = new GridBagConstraints();
        viewButton = new JButton("View Attraction");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 40, 40, 40);
        c.weightx = 0.5;
        c.gridx = 0;
        c.gridy = 1;
        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String s = (String) suggestionsTable.getJTable().getModel().getValueAt(suggestionsTable.getJTable().getSelectedRow(), 0);
                ViewDetailsDialog viewDetailsDialog = new ViewDetailsDialog(j, isClient, s, "suggestPanel");
                viewDetailsDialog.setLocationRelativeTo(frame);
                viewDetailsDialog.setVisible(true);
            }
        });
        add(viewButton, c);

        c = new GridBagConstraints();
        approveButton = new JButton("Approve Suggestion");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 40, 40, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 1;
        approveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (suggestionsTable.getJTable().getSelectedRow() == -1) {
                    JOptionPane.showMessageDialog(null, "Please select a row to view", "Row not selected", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    String s = (String) suggestionsTable.getJTable().getModel().getValueAt(suggestionsTable.getJTable().getSelectedRow(), 0);
                    PaidiaClient.promoteSuggestion(s);
                    refresh();
                }
            }
        });
        add(approveButton, c);

        c = new GridBagConstraints();
        denyButton = new JButton("Deny Suggestion");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 40, 40, 40);
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 1;
        denyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (suggestionsTable.getJTable().getSelectedRow() == -1) {
                    JOptionPane.showMessageDialog(null, "Please select a row to view", "Row not selected", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    String s = (String) suggestionsTable.getJTable().getModel().getValueAt(suggestionsTable.getJTable().getSelectedRow(), 0);
                    PaidiaClient.deleteSuggestion(s);
                    refresh();
                }
            }
        });
        add(denyButton, c);

        refresh();
    }

    public void refresh() {
        tableWidth = HEADERS.length;
        suggestionsTable = new PaidiaTable(HEADERS);
        TableObject row1;
        String[][] result = PaidiaClient.getAllSuggestions();
        if (result != null) {
            for (int i = 0; i < result.length; i++) {
                row1 = new TableObject(tableWidth, new String[]{result[i][0], result[i][5], result[i][1], result[i][3],
                    result[i][2], result[i][4], result[i][11], result[i][12], result[i][6], result[i][7], result[i][10], result[i][8], result[i][9], result[i][13], result[i][14]});
                suggestionsTable.addRow(row1);
            }
            suggestionsTable.getJTable().removeColumn(suggestionsTable.getJTable().getColumnModel().getColumn(14));
            suggestionsTable.getJTable().removeColumn(suggestionsTable.getJTable().getColumnModel().getColumn(13));
            suggestionsTable.getJTable().removeColumn(suggestionsTable.getJTable().getColumnModel().getColumn(12));
            suggestionsTable.getJTable().removeColumn(suggestionsTable.getJTable().getColumnModel().getColumn(11));
            suggestionsTable.getJTable().removeColumn(suggestionsTable.getJTable().getColumnModel().getColumn(10));
            suggestionsTable.getJTable().removeColumn(suggestionsTable.getJTable().getColumnModel().getColumn(9));
            suggestionsTable.getJTable().removeColumn(suggestionsTable.getJTable().getColumnModel().getColumn(8));
            suggestionsTable.getJTable().removeColumn(suggestionsTable.getJTable().getColumnModel().getColumn(0));

            suggestionsTable.getJTable().getColumnModel().getColumn(3).setMaxWidth(32);
            suggestionsTable.getJTable().getColumnModel().getColumn(3).setMinWidth(32);
            
            suggestionsTable.getJTable().getColumnModel().getColumn(2).setMaxWidth(85);
            suggestionsTable.getJTable().getColumnModel().getColumn(2).setMinWidth(85);
            
            suggestionsTable.getJTable().getColumnModel().getColumn(4).setMaxWidth(110);
            suggestionsTable.getJTable().getColumnModel().getColumn(4).setMinWidth(110);
            
            suggestionsTable.getJTable().getColumnModel().getColumn(5).setMaxWidth(100);
            suggestionsTable.getJTable().getColumnModel().getColumn(5).setMinWidth(95);
            
            suggestionsTable.getJTable().changeSelection(0, 0, false, false);
            suggestionsTable.getJTable().repaint();
            suggestionsTable.getJTable().revalidate();
        }

        if (pane != null) {
            remove(pane);
        }
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.PAGE_START;
        c.insets = new Insets(0, 2, 0, 0);
        c.weighty = 1.0;
        c.weightx = 0.0;
        c.gridwidth = 3;
        c.gridx = 0;
        c.gridy = 0;
        pane = new JScrollPane(suggestionsTable.getJTable());
        add(pane, c);
        repaint();
        revalidate();
    }

}
