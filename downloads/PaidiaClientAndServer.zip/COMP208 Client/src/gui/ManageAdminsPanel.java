package gui;

import datarepresentation.PaidiaTable;
import datarepresentation.TableObject;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

/**
 *
 * @author Ben
 */
public class ManageAdminsPanel extends JPanel {

    final String[] HEADERS = {"ID", "Username", "Clearance Level"};

    static JButton addAdminButton;
    static JButton removeAdminButton;
    JButton editAdminButton;
    JFrame frame;
    static int clearanceLevel;
    int tableWidth;
    JScrollPane pane;
    PaidiaTable adminTable;

    public ManageAdminsPanel(JFrame j) {
        frame = j;

        setLayout(new GridBagLayout());

        GridBagConstraints c = new GridBagConstraints();
        addAdminButton = new JButton("Add new admin");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 40, 40, 40);
        c.weightx = 0.5;
        c.gridwidth = 3;
        c.gridx = 0;
        c.gridy = 1;
        addAdminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AddAdminDialog addAdminDialog = new AddAdminDialog(j, "addAdmin", "");
                addAdminDialog.setLocationRelativeTo(frame);
                addAdminDialog.setVisible(true);
            }
        });
        add(addAdminButton, c);

        c = new GridBagConstraints();
        editAdminButton = new JButton("Edit admin");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 40, 40, 40);
        c.gridwidth = 3;
        c.weightx = 0.5;
        c.gridx = 3;
        c.gridy = 1;
        editAdminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String s = (String) adminTable.getJTable().getModel().getValueAt(adminTable.getJTable().getSelectedRow(), 0);
                AddAdminDialog addAdminDialog = new AddAdminDialog(j, "editAdmin", s);
                addAdminDialog.setLocationRelativeTo(frame);
                addAdminDialog.setVisible(true);
            }
        });
        add(editAdminButton, c);

        c = new GridBagConstraints();
        removeAdminButton = new JButton("Remove admin");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 40, 40, 40);
        c.gridwidth = 3;
        c.weightx = 0.5;
        c.gridx = 6;
        c.gridy = 1;
        removeAdminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String s = (String) adminTable.getJTable().getModel().getValueAt(adminTable.getJTable().getSelectedRow(), 0);
                PaidiaClient.deleteAdmin(s);
                refresh();
            }
        });
        add(removeAdminButton, c);

        refresh();
    }

    public void refresh() {
        tableWidth = HEADERS.length;
        adminTable = new PaidiaTable(HEADERS);
        TableObject row1;
        String[][] result = PaidiaClient.getAllAdmins();
        if (result != null) {
            for (int i = 0; i < result.length; i++) {
                row1 = new TableObject(tableWidth, new String[]{result[i][0], result[i][1], result[i][2]});
                adminTable.addRow(row1);
            }
            adminTable.getJTable().removeColumn(adminTable.getJTable().getColumnModel().getColumn(0));

            
            adminTable.getJTable().changeSelection(0, 0, false, false);
            adminTable.getJTable().repaint();
            adminTable.getJTable().revalidate();
        }

        if (pane != null) {
            remove(pane);
        }
        //Add PaidiaTable
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.PAGE_START;
        c.insets = new Insets(0, 2, 0, 0);
        c.weighty = 1.0;
        c.weightx = 0.0;
        c.gridwidth = 9;
        c.gridx = 0;
        c.gridy = 0;
        pane = new JScrollPane(adminTable.getJTable());
        add(pane, c);
        repaint();
        revalidate();
    }

    public static void setClearanceLevel(int clear) {
        clearanceLevel = clear;
        if (clearanceLevel < 3) {
            addAdminButton.setEnabled(false);
            removeAdminButton.setEnabled(false);
        } else {
            addAdminButton.setEnabled(true);
            removeAdminButton.setEnabled(true);
        }
    }

}
