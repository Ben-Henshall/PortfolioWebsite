package gui;

import api.LocationManager;
import api.LocationManager.DirectionSet;
import api.LocationManager.TransportMode;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.IOException;
import java.net.MalformedURLException;
import javax.swing.BoxLayout;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;

/**
 * GUI Swing component displaying directional information extracted from a 
 * valid LocationManager in a formatted way.
 * @author Mike Green - 200922076
 */
public class LocationDialog extends JDialog {

    LocationManager lm;
    String source, destination;
    JPanel directionsOuterPanel;
    
    
    /**
     * Creates an instance of the object with directional information from 
     * a specified source to destination. Provides information for all four 
     * supported transport methods.
     * @param p Parent container.
     * @param src Source location for directions.
     * @param dstn Destination location for directions.
     */
    public LocationDialog(JFrame p, String src, String dstn) {
        super(p, false);
        source = src;
        destination = dstn;
        lm = new LocationManager(source);
        setLayout(new BorderLayout());
        setTitle("Attraction Location");
        setResizable(true);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        
        
        
        // Map
        try {
            JLabel mapLabel = LocationManager.getMap(destination, 15, new Dimension(500, 300));
            add(mapLabel, BorderLayout.NORTH);
        } catch (MalformedURLException ex) {
            System.err.println("Map could not be generated.\n\n"
                        + ex.getMessage());
        }
        
        
        // Directions
        JTabbedPane contentTabPane = new JTabbedPane();
        contentTabPane.addTab("Driving", generateDirectionsPanel(TransportMode.DRIVING));
        contentTabPane.addTab("Cycling", generateDirectionsPanel(TransportMode.BICYCLING));
        contentTabPane.addTab("Walking", generateDirectionsPanel(TransportMode.WALKING));
        contentTabPane.addTab("Transit", generateDirectionsPanel(TransportMode.TRANSIT));
        add(contentTabPane, BorderLayout.CENTER);
        
        setSize(600, 700);
        setVisible(true);
    }
    
    
    /**
     * Generates a JScrollPanel containing a set of directions in a formatted 
     * manner from the related source to destination.
     * @param mode The mode of transport to be used.
     * @return A JScrollPane containing a set of directions for the given 
     * transport method.
     */
    private JScrollPane generateDirectionsPanel(TransportMode mode){
        DirectionSet directionsText = null;
        JPanel directionsPanel = new JPanel();
        directionsPanel.setLayout(new BoxLayout(directionsPanel, BoxLayout.Y_AXIS));
        try {
            directionsText = lm.directionsTo(destination, mode);
        } catch (IOException ex) {
            System.err.println("Directions could not be generated.\n\n"
                        + ex.getMessage());
        }
        int steps = directionsText.getSteps();
        JLabel[] stepsLabel = new JLabel[steps];  // 1 label for each step
        String labelString;
        for(int i = 0; i < steps; i++){
            if(directionsText.getInstructions()[i] == null){
                continue;
            }
            labelString = "<html>" + directionsText.getInstructions()[i] + 
                    "<br>Distance: " + directionsText.getDistance()[i] + "<br>" + 
                    "Duration: " + directionsText.getDuration()[i];
            if(directionsText.getInstructions()[i].toUpperCase().contains("BUS")){
                labelString = labelString + "<br>" + "Bus Number: " + directionsText.getTransitNumber()[i];
            }
            labelString = labelString + "<br><br></html>";  // close string
            stepsLabel[i] = new JLabel(labelString);
            directionsPanel.add(stepsLabel[i]);
        }
        JScrollPane directionsScrollPane = new JScrollPane(directionsPanel);

        return directionsScrollPane;
    }
    
}
