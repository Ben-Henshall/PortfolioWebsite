package gui;

import datarepresentation.TableObject;
import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import static java.lang.System.exit;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

public class PaidiaClient {

    static boolean isClient = true;
    static CardLayout actorContainerLayout = new CardLayout();
    static JPanel actorContainer = new JPanel();
    static JButton viewAdmins;
    static ActorCard adminCard;
    static ActorCard clientCard;
    static JButton viewAttractionsAdmin;

    private static final int PORT_NUM = 12028;
    private static final String HOSTNAME = "82.44.235.21";
    static Socket client;
    static BufferedReader in;
    static PrintWriter out;
    public static ExistingAttractionsPanel existingAttractionsPanel;
    public static ExistingAttractionsPanel existingAttractionsPanel2;
    public static SuggestionsPanel suggestionsPanel;
    public static ManageAdminsPanel manageAdminsPanel;
    public static JFrame frame;
    public static JPanel adminContent[] = new JPanel[3];

    static Properties mailServerProperties;
    static Session getMailSession;
    static MimeMessage generateMailMessage;

    public static void main(String[] args) {
        PaidiaClient paidiaClient = new PaidiaClient();
    }

    public PaidiaClient() {
        frame = new JFrame("Paidia UI Prototype");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        try {
            // Set System L&F
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | UnsupportedLookAndFeelException ex) {
            Logger.getLogger(PaidiaClient.class.getName()).log(Level.SEVERE, null, ex);
        }

        //ExistingAttractionsPanel existingAttractionsPanel = new ExistingAttractionsPanel();
        //frame.add(existingAttractionsPanel);
        actorContainer.setLayout(actorContainerLayout);
        frame.add(actorContainer);

        //INIT CLIENT VIEW
        existingAttractionsPanel = new ExistingAttractionsPanel(frame, true);    //CONSTRUCTOR IS NEEDED TO SPECIFY IF CLIENT OR NOT
        JPanel clientContent[] = new JPanel[1];
        clientContent[0] = existingAttractionsPanel;
        clientCard = new ActorCard(clientContent);
        actorContainer.add(clientCard, "client");

        //INIT ADMIN VIEW
        existingAttractionsPanel2 = new ExistingAttractionsPanel(frame, false);   //had to use 2 instances because if only one is used, doesn't show JPANEL for both(?)
        adminContent[0] = existingAttractionsPanel2;
        suggestionsPanel = new SuggestionsPanel(frame, false);
        adminContent[1] = suggestionsPanel;
        manageAdminsPanel = new ManageAdminsPanel(frame);
        adminContent[2] = manageAdminsPanel;
        adminCard = new ActorCard(adminContent);
        actorContainer.add(adminCard, "admin");

        //Admin switch
        JButton switchToAdminButton = new JButton("Admin Area");
        switchToAdminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                LoginScreenDialog loginScreenDialog = new LoginScreenDialog(frame);
                loginScreenDialog.setLocationRelativeTo(frame);
                loginScreenDialog.setVisible(true);
            }
        });
        clientCard.getSwitchPanel().add(switchToAdminButton);

        //Client switch
        JButton switchToClientButton = new JButton("Back to user view");
        switchToClientButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actorContainerLayout.show(actorContainer, "client");
                isClient = true;
                refreshExistingAttractions();
            }
        });
        adminCard.getSwitchPanel().add(switchToClientButton);

        JLabel space2 = new JLabel("   ");
        adminCard.getNavigationPanel().add(space2);
        
        /*
         **ADMIN
         */
        //View suggestions admin card
        JButton viewSuggestionsAdmin = new JButton("          View Suggestions          ");
        viewSuggestionsAdmin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshSuggestions();
                adminCard.getContentLayout().show(adminCard.getContentPanel(), "2");
            }
        });
        adminCard.getNavigationPanel().add(viewSuggestionsAdmin);
        //View attractions admin card
        viewAttractionsAdmin = new JButton("           View Attractions          ");
        viewAttractionsAdmin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshExistingAttractions();
                adminCard.getContentLayout().show(adminCard.getContentPanel(), "1");
            }
        });
        adminCard.getNavigationPanel().add(viewAttractionsAdmin);
        //View suggestions admin card
        viewAdmins = new JButton("           Manage Admins           ");
        viewAdmins.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshAdmins();
                adminCard.getContentLayout().show(adminCard.getContentPanel(), "3");
            }
        });
        adminCard.getNavigationPanel().add(viewAdmins);

        ImageIcon image = new ImageIcon(getClass().getResource("goat.png"));
        JLabel label = new JLabel(image);
        JLabel label2 = new JLabel(image);
        clientCard.getNavigationPanel().add(label,SwingConstants.CENTER);
        adminCard.getNavigationPanel().add(label2,SwingConstants.CENTER);
        
        JLabel space = new JLabel("   ");
        
        clientCard.getNavigationPanel().add(space);
        
        
        /*
         **CLIENT
         */
        //View attractions client

        //Client content 2 
        JButton suggestClient = new JButton("      Suggest an Attraction      ");
        suggestClient.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //show dialog for adding suggestion
                ViewDetailsDialog suggestDetailsDialog = new ViewDetailsDialog(frame, false, "", "suggestNew");
                suggestDetailsDialog.setLocationRelativeTo(frame);
                suggestDetailsDialog.setVisible(true);
            }
        });
        clientCard.getNavigationPanel().add(suggestClient);

        //set size of programme
        frame.setSize(1200, 600);
        frame.setVisible(true);
        frame.setLocation((java.awt.Toolkit.getDefaultToolkit().getScreenSize().width / 2) - 600, (java.awt.Toolkit.getDefaultToolkit().getScreenSize().height / 2) - 300);
        frame.setResizable(false);
    }

    public static void switchToAdmin(int clear) {
        actorContainerLayout.show(actorContainer, "admin");
        adminCard.getContentLayout().show(adminCard.getContentPanel(), "2");
        if (clear < 3) {
            viewAdmins.setEnabled(false);
        } else {
            viewAdmins.setEnabled(true);
        }
        if (clear < 2) {
            viewAttractionsAdmin.setEnabled(false);
        } else {
            viewAttractionsAdmin.setEnabled(true);
        }
        isClient = false;
        refreshSuggestions();
    }

    public static void refreshExistingAttractions() {
        existingAttractionsPanel.refresh();
        existingAttractionsPanel2.refresh();
    }

    public static void refreshSuggestions() {
        suggestionsPanel.refresh();
    }

    public static void refreshAdmins() {
        manageAdminsPanel.refresh();
    }

    public void switchToClient() {

    }

    public static void setUpConnection() {
        try {
            client = new Socket(HOSTNAME, PORT_NUM);
            in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            out = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Unable to connect to the server. Please check your internet connection.", "Connection Error", JOptionPane.ERROR_MESSAGE);
            exit(1);    // Return code 1: Server could not be found
        }

    }

    public static String[][] getSpecificAttraction(String id) {
        setUpConnection();
        String[][] array = null;
        out.println("3");
        out.println(id);
        out.flush();
        String line;
        try {
            while ((line = in.readLine()) != null) {
                array = TableObject.convertStringToArray(removeNewlines(line));
            }

        } catch (IOException ex) {
            Logger.getLogger(ViewDetailsDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
        return array;
    }

    public static String[][] getAllExistingAttractions() {
        setUpConnection();
        String[][] array = null;
        out.println("1");
        out.flush();
        String line;
        try {
            while ((line = in.readLine()) != null) {
                array = TableObject.convertStringToArray(removeNewlines(line));
            }

        } catch (IOException ex) {
            Logger.getLogger(ViewDetailsDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
        return array;
    }

    public static String[][] getFilteredAttractions(String type, String cost, String participants, String openHours) {
        setUpConnection();
        String[][] array = null;
        out.println("10");
        out.println(type);
        out.println(cost);
        out.println(participants);
        out.println(openHours);
        out.flush();
        String line;
        try {
            while ((line = in.readLine()) != null) {
                array = TableObject.convertStringToArray(removeNewlines(line));
            }

        } catch (IOException ex) {
            Logger.getLogger(ViewDetailsDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
        return array;
    }

    public static String[][] getAllSuggestions() {
        setUpConnection();
        String[][] array = null;
        out.println("2");
        out.flush();
        String line;
        try {
            while ((line = in.readLine()) != null) {
                array = TableObject.convertStringToArray(removeNewlines(line));
            }

        } catch (IOException ex) {
            Logger.getLogger(ViewDetailsDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
        return array;

    }

    public static String removeNewlines(String s) {
        s = s.replaceAll("\n", "");
        s = s.replaceAll("\r", "");
        return s;
    }

    public static String[][] getAllAdmins() {
        setUpConnection();
        String[][] array = null;
        out.println("8");
        out.flush();
        String line;
        try {
            while ((line = in.readLine()) != null) {
                array = TableObject.convertStringToArray(removeNewlines(line));
            }

        } catch (IOException ex) {
            Logger.getLogger(ViewDetailsDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
        return array;
    }

    public static String[][] getSpecificAdmin(String id) {
        setUpConnection();
        String[][] array = null;
        out.println("11");    //FIX
        out.println(id);
        out.flush();
        String line;
        try {
            while ((line = in.readLine()) != null) {
                array = TableObject.convertStringToArray(removeNewlines(line));
            }

        } catch (IOException ex) {
            Logger.getLogger(ViewDetailsDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
        return array;

    }

    public static String addAdmin(String user, String pass, String clear) {
        setUpConnection();
        out.println("4");
        out.println(user);
        out.println(pass);
        out.println(clear);
        out.flush();
        String line;
        try {
            while ((line = in.readLine()) != null) {
                return removeNewlines(line);
            }

        } catch (IOException ex) {
            Logger.getLogger(ViewDetailsDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    public static String promoteAdmin(String id, String clear) {
        setUpConnection();
        out.println("12");    //PLACEHOLDER
        out.println(id);
        out.println(clear);
        out.flush();
        String line;
        try {
            while ((line = in.readLine()) != null) {
                return removeNewlines(line);
            }

        } catch (IOException ex) {
            Logger.getLogger(ViewDetailsDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;

    }

    public static int login(String user, String pass) {
        setUpConnection();
        out.println("6");
        out.println(user);
        out.println(pass);
        out.flush();
        String line;
        try {
            while ((line = in.readLine()) != null) {
                int output = Integer.parseInt(removeNewlines(line));
                return output;
            }

        } catch (IOException ex) {
            Logger.getLogger(ViewDetailsDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;

    }

    public static int deleteAttraction(String id) {
        setUpConnection();
        out.println("5");
        out.println(id);
        out.flush();
        String line;
        try {
            while ((line = in.readLine()) != null) {
                int output = Integer.parseInt(removeNewlines(line));
                return output;
            }

        } catch (IOException ex) {
            Logger.getLogger(ViewDetailsDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;

    }

    public static int deleteAdmin(String id) {
        setUpConnection();
        out.println("9");
        out.println(id);
        out.flush();
        String line;
        try {
            while ((line = in.readLine()) != null) {
                int output = Integer.parseInt(removeNewlines(line));
                return output;
            }

        } catch (IOException ex) {
            Logger.getLogger(ViewDetailsDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;

    }

    public static int deleteSuggestion(String id) {
        setUpConnection();
        out.println("5");
        out.println(id);
        out.flush();
        String line;
        try {
            while ((line = in.readLine()) != null) {
                int output = Integer.parseInt(removeNewlines(line));
                return output;
            }

        } catch (IOException ex) {
            Logger.getLogger(ViewDetailsDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;

    }

    public static int addSuggestion(String activityType, String cost, String openingHours, String minParticipants, String attractionName, String address1, String address2, String townCity,
            String county, String postcode, String telephoneNo, String website, String email, String description) {
        setUpConnection();
        out.println("0");
        out.println("0");   //0 == suggestion
        out.println(attractionName);
        out.println(description);
        out.println(activityType);
        out.println(cost);
        out.println(minParticipants);
        out.println(openingHours);
        out.println(telephoneNo);
        out.println(email);
        out.println(website);
        out.println(address1);
        out.println(address2);
        out.println(townCity);
        out.println(county);
        out.println(postcode);
        out.println(activityType);
        out.flush();
        String line;
        try {
            while ((line = in.readLine()) != null) {
                int output = Integer.parseInt(removeNewlines(line));
                return output;
            }

        } catch (IOException ex) {
            Logger.getLogger(ViewDetailsDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    public static int addAttraction(String activityType, String cost, String openingHours, String minParticipants, String attractionName, String address1, String address2, String townCity,
            String county, String postcode, String telephoneNo, String website, String email, String description) {
        setUpConnection();
        out.println("0");
        out.println("1");   //0 == suggestion
        out.println(attractionName);
        out.println(description);
        out.println(activityType);
        out.println(cost);
        out.println(minParticipants);
        out.println(openingHours);
        out.println(telephoneNo);
        out.println(email);
        out.println(website);
        out.println(address1);
        out.println(address2);
        out.println(townCity);
        out.println(county);
        out.println(postcode);
        out.println(activityType);
        out.flush();
        String line;
        try {
            while ((line = in.readLine()) != null) {
                int output = Integer.parseInt(removeNewlines(line));
                return output;
            }

        } catch (IOException ex) {
            Logger.getLogger(ViewDetailsDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }

    public static void generateAndSendEmail(String id, String typeOfEmail) throws AddressException, MessagingException {
        mailServerProperties = System.getProperties();
        mailServerProperties.put("mail.smtp.port", "587");
        mailServerProperties.put("mail.smtp.auth", "true");
        mailServerProperties.put("mail.smtp.starttls.enable", "true");

        getMailSession = Session.getDefaultInstance(mailServerProperties, null);
        generateMailMessage = new MimeMessage(getMailSession);
        generateMailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress("paidianotifier@gmail.com"));
        String emailBody;
        if (typeOfEmail.equals("report")) {
            generateMailMessage.setSubject("Attraction reported as out of date!");
            String[][] result = PaidiaClient.getSpecificAttraction(id);
            emailBody = "The following entry has been reported as out of date:" + "\r\n" + "\r\n"
                    + "Name: " + result[0][5] + "\r\n"
                    + "Activity Type: " + result[0][1] + "\r\n"
                    + "Cost: " + result[0][2] + "\r\n"
                    + "Opening Hours: " + result[0][3] + "\r\n"
                    + "Minimum Participants: " + result[0][4] + "\r\n"
                    + "Address 1: " + result[0][6] + "\r\n"
                    + "Address 2: " + result[0][7] + "\r\n"
                    + "Town/City: " + result[0][8] + "\r\n"
                    + "County: " + result[0][9] + "\r\n"
                    + "Postcode: " + result[0][10] + "\r\n"
                    + "Telephone No.: " + result[0][11] + "\r\n"
                    + "Website: " + result[0][12] + "\r\n"
                    + "E-mail: " + result[0][13] + "\r\n"
                    + "Description: " + result[0][14];
        } else {
            generateMailMessage.setSubject("A new attraction has been suggested");
            int rowCount = suggestionsPanel.suggestionsTable.getJTable().getRowCount();
            String idEmail = suggestionsPanel.suggestionsTable.getJTable().getModel().getValueAt(rowCount-1, 0).toString();
            String[][] result = PaidiaClient.getSpecificAttraction(idEmail);
            emailBody = "The following attraction has been suggested:" + "\r\n" + "\r\n"
                    + "Name: " + result[0][5] + "\r\n"
                    + "Activity Type: " + result[0][1] + "\r\n"
                    + "Cost: " + result[0][2] + "\r\n"
                    + "Opening Hours: " + result[0][3] + "\r\n"
                    + "Minimum Participants: " + result[0][4] + "\r\n"
                    + "Address 1: " + result[0][6] + "\r\n"
                    + "Address 2: " + result[0][7] + "\r\n"
                    + "Town/City: " + result[0][8] + "\r\n"
                    + "County: " + result[0][9] + "\r\n"
                    + "Postcode: " + result[0][10] + "\r\n"
                    + "Telephone No.: " + result[0][11] + "\r\n"
                    + "Website: " + result[0][12] + "\r\n"
                    + "E-mail: " + result[0][13] + "\r\n"
                    + "Description: " + result[0][14];
        }
        generateMailMessage.setContent(emailBody, "text/plain; charset=UTF-8");

        Transport transport = getMailSession.getTransport("smtp");

        transport.connect("smtp.gmail.com", "paidianotifier@gmail.com", "paidia123");
        transport.sendMessage(generateMailMessage, generateMailMessage.getAllRecipients());
        transport.close();
    }
    
    
    public static void promoteSuggestion(String id) {
        setUpConnection();
        out.println("7");
        out.println(id);
        out.flush();
    }

}
