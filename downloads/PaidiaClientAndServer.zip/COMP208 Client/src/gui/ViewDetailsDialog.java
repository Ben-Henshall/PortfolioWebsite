package gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.MessagingException;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Ben
 */
public class ViewDetailsDialog extends JDialog {

    JLabel activityTypeLabel;
    JLabel costLabel;
    JLabel openingHoursLabel;
    JLabel minParticipantsLabel;
    JLabel attractionNameLabel;
    JLabel address1Label;
    JLabel address2Label;
    JLabel townCityLabel;
    JLabel countyLabel;
    JLabel postcodeLabel;
    JLabel telephoneNoLabel;
    JLabel websiteLabel;
    JLabel emailLabel;
    JLabel descriptionLabel;

    JComboBox activityTypeCombo;
    JComboBox costCombo;
    JComboBox openingHoursCombo;
    JComboBox minParticipantsCombo;
    JTextField attractionNameTextField;
    JTextField address1TextField;
    JTextField address2TextField;
    JTextField townCityTextField;
    JTextField countyTextField;
    JTextField postcodeTextField;
    JTextField telephoneNoTextField;
    JTextField websiteTextField;
    JTextField emailTextField;
    JTextArea descriptionTextArea;

    JButton submitButton;
    JButton exitButton;
    JButton reportButton;
    JFrame parent;

    boolean isClient;

    Socket client;
    BufferedReader in;
    PrintWriter out;
    String id;
    String[][] result;

    String activePanel;

    public ViewDetailsDialog(JFrame p, boolean b, String s, String panel) {
        super(p, true);
        setLayout(new GridBagLayout());
        parent = p;
        isClient = b;
        id = s;
        activePanel = panel;

        setSize(450, 800);
        if (isClient == true) {
            if (activePanel.equals("filter")) {
                setTitle("Filter Details");
            } else {
                setTitle("View Details");
            }
        } else {
            setTitle("Edit Details");
        }
        setResizable(false);

        GridBagConstraints c = new GridBagConstraints();
        activityTypeLabel = new JLabel("Activity Type:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 0;
        add(activityTypeLabel, c);

        c = new GridBagConstraints();
        activityTypeCombo = new JComboBox();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 0;
        add(activityTypeCombo, c);
        activityTypeCombo.addItem("Sights and Landmarks");
        activityTypeCombo.addItem("Museums");
        activityTypeCombo.addItem("Outdoor Activities");
        activityTypeCombo.addItem("Tours");
        activityTypeCombo.addItem("Shopping");
        activityTypeCombo.addItem("Fun and Games");
        activityTypeCombo.addItem("Water Sports");
        activityTypeCombo.addItem("Sports");
        activityTypeCombo.addItem("Theatre and Concerts");
        activityTypeCombo.addItem("Nature and Parks");
        activityTypeCombo.addItem("Spa and Wellness");

        c = new GridBagConstraints();
        costLabel = new JLabel("Cost:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 1;
        add(costLabel, c);

        c = new GridBagConstraints();
        costCombo = new JComboBox();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 1;
        add(costCombo, c);
        costCombo.addItem("$");
        costCombo.addItem("$$");
        costCombo.addItem("$$$");

        c = new GridBagConstraints();
        openingHoursLabel = new JLabel("Opening Hours:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 2;
        add(openingHoursLabel, c);

        c = new GridBagConstraints();
        openingHoursCombo = new JComboBox();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 2;
        add(openingHoursCombo, c);
        openingHoursCombo.addItem("Day");
        openingHoursCombo.addItem("Night");

        c = new GridBagConstraints();
        minParticipantsLabel = new JLabel("Minimum Participants:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 3;
        add(minParticipantsLabel, c);

        c = new GridBagConstraints();
        minParticipantsCombo = new JComboBox();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 3;
        add(minParticipantsCombo, c);
        minParticipantsCombo.addItem("1");
        minParticipantsCombo.addItem("2");
        minParticipantsCombo.addItem("3");
        minParticipantsCombo.addItem("4");
        minParticipantsCombo.addItem("5");
        minParticipantsCombo.addItem("6");
        minParticipantsCombo.addItem("7");
        minParticipantsCombo.addItem("8");
        minParticipantsCombo.addItem("9");

        c = new GridBagConstraints();
        attractionNameLabel = new JLabel("Attraction Name:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 4;
        add(attractionNameLabel, c);

        c = new GridBagConstraints();
        attractionNameTextField = new JTextField();
        attractionNameTextField.setDocument(new JTextFieldLimit(50));
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 4;
        add(attractionNameTextField, c);

        c = new GridBagConstraints();
        address1Label = new JLabel("Address 1:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 5;
        add(address1Label, c);

        c = new GridBagConstraints();
        address1TextField = new JTextField();
        address1TextField.setDocument(new JTextFieldLimit(40));
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 5;
        add(address1TextField, c);

        c = new GridBagConstraints();
        address2Label = new JLabel("Address 2:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 6;
        add(address2Label, c);

        c = new GridBagConstraints();
        address2TextField = new JTextField();
        address2TextField.setDocument(new JTextFieldLimit(40));
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 6;
        add(address2TextField, c);

        c = new GridBagConstraints();
        townCityLabel = new JLabel("Town/City:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 7;
        add(townCityLabel, c);

        c = new GridBagConstraints();
        townCityTextField = new JTextField();
        townCityTextField.setDocument(new JTextFieldLimit(40));
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 7;
        add(townCityTextField, c);

        c = new GridBagConstraints();
        countyLabel = new JLabel("County:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 8;
        add(countyLabel, c);

        c = new GridBagConstraints();
        countyTextField = new JTextField();
        countyTextField.setDocument(new JTextFieldLimit(50));
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 8;
        add(countyTextField, c);

        c = new GridBagConstraints();
        postcodeLabel = new JLabel("Postcode:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 9;
        add(postcodeLabel, c);

        c = new GridBagConstraints();
        postcodeTextField = new JTextField();
        postcodeTextField.setDocument(new JTextFieldLimit(9));
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 9;
        add(postcodeTextField, c);

        c = new GridBagConstraints();
        telephoneNoLabel = new JLabel("Telephone No.:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 10;
        add(telephoneNoLabel, c);

        c = new GridBagConstraints();
        telephoneNoTextField = new JTextField();
        telephoneNoTextField.setDocument(new JTextFieldLimit(15));
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 10;
        add(telephoneNoTextField, c);

        c = new GridBagConstraints();
        websiteLabel = new JLabel("Website:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 11;
        add(websiteLabel, c);

        c = new GridBagConstraints();
        websiteTextField = new JTextField();
        websiteTextField.setDocument(new JTextFieldLimit(40));
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 11;
        add(websiteTextField, c);

        c = new GridBagConstraints();
        emailLabel = new JLabel("Email Address:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 12;
        add(emailLabel, c);

        c = new GridBagConstraints();
        emailTextField = new JTextField();
        emailTextField.setDocument(new JTextFieldLimit(40));
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 12;
        add(emailTextField, c);

        c = new GridBagConstraints();
        descriptionLabel = new JLabel("Description:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 13;
        add(descriptionLabel, c);

        c = new GridBagConstraints();
        descriptionTextArea = new JTextArea();
        descriptionTextArea.setDocument(new JTextFieldLimit(1000));
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 40);
        c.weightx = 0.5;
        c.gridheight = 3;
        c.gridx = 1;
        c.gridy = 13;
        descriptionTextArea.setRows(8);
        descriptionTextArea.setLineWrap(true);
        JScrollPane scroll = new JScrollPane(descriptionTextArea);
        add(scroll, c);

        if (isClient == false) {
            c = new GridBagConstraints();
            submitButton = new JButton("Confirm");
            c.fill = GridBagConstraints.HORIZONTAL;
            c.insets = new Insets(20, 60, 0, 40);
            c.weightx = 0;
            c.gridx = 0;
            c.gridy = 16;

            submitButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    try {
                        submit();
                    } catch (MessagingException ex) {
                        Logger.getLogger(ViewDetailsDialog.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
            add(submitButton, c);
        }

        c = new GridBagConstraints();
        exitButton = new JButton("Exit");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(20, 40, 0, 60);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 16;
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exitDialog();
            }
        });
        add(exitButton, c);

        if (!activePanel.equals("suggestNew")) {
            c = new GridBagConstraints();
            reportButton = new JButton("Information out of date");
            c.fill = GridBagConstraints.HORIZONTAL;
            c.insets = new Insets(20, 125, 0, 125);
            c.weightx = 0;
            c.gridwidth = 2;
            c.gridx = 0;
            c.gridy = 17;

            reportButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    try {
                        PaidiaClient.generateAndSendEmail(id, "report");
                    } catch (MessagingException ex) {
                        Logger.getLogger(ViewDetailsDialog.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            });
            add(reportButton, c);
        }

        activityTypeCombo.setEnabled(!isClient);
        costCombo.setEnabled(!isClient);
        openingHoursCombo.setEnabled(!isClient);
        minParticipantsCombo.setEnabled(!isClient);
        attractionNameTextField.setEnabled(!isClient);
        address1TextField.setEnabled(!isClient);
        address2TextField.setEnabled(!isClient);
        townCityTextField.setEnabled(!isClient);
        countyTextField.setEnabled(!isClient);
        postcodeTextField.setEnabled(!isClient);
        telephoneNoTextField.setEnabled(!isClient);
        websiteTextField.setEnabled(!isClient);
        emailTextField.setEnabled(!isClient);
        descriptionTextArea.setEnabled(!isClient);
this.getRootPane().setDefaultButton(submitButton);
        if (!activePanel.equals("filter")) {
            if (!id.equals("")) {
                result = PaidiaClient.getSpecificAttraction(id);
                if (result != null) {
                    activityTypeCombo.setSelectedItem(result[0][1]);
                    costCombo.setSelectedItem(result[0][2]);
                    openingHoursCombo.setSelectedItem(result[0][3]);
                    minParticipantsCombo.setSelectedItem(result[0][4]);
                    attractionNameTextField.setText(result[0][5]);
                    address1TextField.setText(result[0][6]);
                    address2TextField.setText(result[0][7]);
                    townCityTextField.setText(result[0][8]);
                    countyTextField.setText(result[0][9]);
                    postcodeTextField.setText(result[0][10]);
                    telephoneNoTextField.setText(result[0][11]);
                    websiteTextField.setText(result[0][12]);
                    emailTextField.setText(result[0][13]);
                    descriptionTextArea.setText(result[0][14]);
                }
            }
        }

    }

    void submit() throws MessagingException {
        if (attractionNameTextField.getText().contains("'")
                || address1TextField.getText().contains("'")
                || address2TextField.getText().contains("'")
                || townCityTextField.getText().contains("'")
                || countyTextField.getText().contains("'")
                || postcodeTextField.getText().contains("'")
                || telephoneNoTextField.getText().contains("'")
                || websiteTextField.getText().contains("'")
                || emailTextField.getText().contains("'")
                || descriptionTextArea.getText().contains("'")) {
            String s;
            attractionNameTextField.setText(attractionNameTextField.getText().replaceAll("'", ""));
            address1TextField.setText(address1TextField.getText().replaceAll("'", ""));
            address2TextField.setText(address2TextField.getText().replaceAll("'", ""));
            townCityTextField.setText(townCityTextField.getText().replaceAll("'", ""));
            countyTextField.setText(countyTextField.getText().replaceAll("'", ""));
            postcodeTextField.setText(postcodeTextField.getText().replaceAll("'", ""));
            telephoneNoTextField.setText(telephoneNoTextField.getText().replaceAll("'", ""));
            websiteTextField.setText(websiteTextField.getText().replaceAll("'", ""));
            emailTextField.setText(emailTextField.getText().replaceAll("'", ""));
            descriptionTextArea.setText(descriptionTextArea.getText().replaceAll("'", ""));
        }

        if (activePanel.equals("suggestNew")) {
            PaidiaClient.addSuggestion(
                    activityTypeCombo.getSelectedItem().toString(),
                    costCombo.getSelectedItem().toString(),
                    openingHoursCombo.getSelectedItem().toString(),
                    minParticipantsCombo.getSelectedItem().toString(),
                    attractionNameTextField.getText(),
                    address1TextField.getText(),
                    address2TextField.getText(),
                    townCityTextField.getText(),
                    countyTextField.getText(),
                    postcodeTextField.getText(),
                    telephoneNoTextField.getText(),
                    websiteTextField.getText(),
                    emailTextField.getText(),
                    descriptionTextArea.getText()
            );
            PaidiaClient.refreshExistingAttractions();
            PaidiaClient.refreshSuggestions();
            PaidiaClient.generateAndSendEmail("", "suggest");
        } else if (activePanel.equals("existing")) {
            PaidiaClient.addAttraction(
                    activityTypeCombo.getSelectedItem().toString(),
                    costCombo.getSelectedItem().toString(),
                    openingHoursCombo.getSelectedItem().toString(),
                    minParticipantsCombo.getSelectedItem().toString(),
                    attractionNameTextField.getText(),
                    address1TextField.getText(),
                    address2TextField.getText(),
                    townCityTextField.getText(),
                    countyTextField.getText(),
                    postcodeTextField.getText(),
                    telephoneNoTextField.getText(),
                    websiteTextField.getText(),
                    emailTextField.getText(),
                    descriptionTextArea.getText()
            );
            PaidiaClient.deleteAttraction(id);
            PaidiaClient.refreshExistingAttractions();
        } else if (activePanel.equals("suggestPanel")) {
            PaidiaClient.addSuggestion(
                    activityTypeCombo.getSelectedItem().toString(),
                    costCombo.getSelectedItem().toString(),
                    openingHoursCombo.getSelectedItem().toString(),
                    minParticipantsCombo.getSelectedItem().toString(),
                    attractionNameTextField.getText(),
                    address1TextField.getText(),
                    address2TextField.getText(),
                    townCityTextField.getText(),
                    countyTextField.getText(),
                    postcodeTextField.getText(),
                    telephoneNoTextField.getText(),
                    websiteTextField.getText(),
                    emailTextField.getText(),
                    descriptionTextArea.getText()
            );
            PaidiaClient.deleteSuggestion(id);
            PaidiaClient.refreshSuggestions();
        }
        dispose();
    }

    void exitDialog() {
        if (activePanel.equals("existing") || activePanel.equals("suggestNew")) {
            PaidiaClient.refreshExistingAttractions();
        } else if (activePanel.equals("suggestPanel")) {
            PaidiaClient.refreshSuggestions();
        }
        dispose();
    }
}
