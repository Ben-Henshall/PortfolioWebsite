package gui;

import datarepresentation.PaidiaTable;
import datarepresentation.TableObject;
import static gui.ManageAdminsPanel.clearanceLevel;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

/**
 *
 * @author Ben
 */
public class ExistingAttractionsPanel extends JPanel {

    final String[] HEADERS = {"ID", "Name", "Activity Type", "Opening Hours", "Cost", "Minimum participants", "Telephone No.", "Website", "Address 1",
        "Address 2", "Postcode", "Town/city", "County", "Email", "Description"};

    JButton viewButton;
    JButton removeButton;
    JButton filterButton;
    JTextField postcodeField;
    JButton mapButton;
    boolean isClient;
    JFrame frame;
    int tableWidth;
    PaidiaTable attractionsTable;
    JButton updateButton;
    JScrollPane pane;

    String filterActivityType = "";
    String filterCost = "";
    String filterParticipants = "";
    String filterOpenHours = "";

    public ExistingAttractionsPanel(JFrame j, boolean b) {
        //ViewDetailsDialog viewDetailsDialog = new ViewDetailsDialog(j,true);
        //viewDetailsDialog.setVisible(false);
        frame = j;
        isClient = b;

        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        c.fill = GridBagConstraints.HORIZONTAL;
        c = new GridBagConstraints();
        postcodeField = new JTextField("Postcode");
        postcodeField.setDocument(new JTextFieldLimit(9));
        postcodeField.setText("Postcode");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 0, 20, 20);
        c.weightx = 0.2;
        c.gridx = 5;
        c.gridy = 2;
        add(postcodeField, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c = new GridBagConstraints();
        mapButton = new JButton("Get Directions from");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 40, 20, 0);
        c.weightx = 0.5;
        c.gridx = 4;
        c.gridy = 2;
        mapButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                LocationDialog locationDialog = new LocationDialog(j, postcodeField.getText(), (String) attractionsTable.getJTable().getModel().getValueAt(attractionsTable.getJTable().getSelectedRow(), 10));
                locationDialog.setLocationRelativeTo(frame);
            }
        });
        add(mapButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c = new GridBagConstraints();
        viewButton = new JButton("");
        if (isClient == false) {
            viewButton.setText("View/Edit Attraction");
        } else {
            viewButton.setText("View Attraction");
        }
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 40, 40, 40);
        c.weightx = 0.5;
        c.gridwidth = 2;
        c.gridx = 0;
        c.gridy = 1;
        viewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (attractionsTable.getJTable().getSelectedRow() == -1) {
                    JOptionPane.showMessageDialog(null, "Please select a row to view", "Row not selected", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    String s = (String) attractionsTable.getJTable().getModel().getValueAt(attractionsTable.getJTable().getSelectedRow(), 0);
                    ViewDetailsDialog viewDetailsDialog = new ViewDetailsDialog(j, isClient, s, "existing");
                    viewDetailsDialog.setLocationRelativeTo(frame);
                    viewDetailsDialog.setVisible(true);
                }
            }
        });
        add(viewButton, c);

        c.fill = GridBagConstraints.HORIZONTAL;
        c = new GridBagConstraints();
        filterButton = new JButton("Filter Attraction");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 40, 40, 40);
        c.weightx = 0.5;
        c.gridwidth = 2;
        c.gridx = 2;
        c.gridy = 1;
        filterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                FilterDialog filterDialog = new FilterDialog(frame, isClient, filterActivityType, filterCost, filterParticipants, filterOpenHours);
                filterDialog.setLocationRelativeTo(frame);
                filterDialog.setVisible(true);
            }
        });
        add(filterButton, c);

        if (isClient == false) {
            c = new GridBagConstraints();
            removeButton = new JButton("Remove Attraction");
            c.fill = GridBagConstraints.HORIZONTAL;
            c.insets = new Insets(0, 40, 40, 40);
            c.weightx = 0.5;
            c.gridwidth = 2;
            c.gridx = 4;
            c.gridy = 1;
            removeButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (attractionsTable.getJTable().getSelectedRow() == -1) {
                        JOptionPane.showMessageDialog(null, "Please select a row to view", "Row not selected", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        String s = (String) attractionsTable.getJTable().getModel().getValueAt(attractionsTable.getJTable().getSelectedRow(), 0);
                        PaidiaClient.deleteAttraction(s);
                        refresh();
                    }
                }
            });
            add(removeButton, c);
        }

        refresh();

    }

    public void refresh() {
        tableWidth = HEADERS.length;
        attractionsTable = new PaidiaTable(HEADERS);
        TableObject row1;
        String[][] result = PaidiaClient.getFilteredAttractions(filterActivityType, filterCost, filterParticipants, filterOpenHours);
        if (result != null) {
            for (int i = 0; i < result.length; i++) {
                row1 = new TableObject(tableWidth, new String[]{result[i][0], result[i][5], result[i][1], result[i][3],
                    result[i][2], result[i][4], result[i][11], result[i][12], result[i][6], result[i][7], result[i][10], result[i][8], result[i][9], result[i][13], result[i][14]});
                attractionsTable.addRow(row1);
            }

            attractionsTable.getJTable().removeColumn(attractionsTable.getJTable().getColumnModel().getColumn(14));
            attractionsTable.getJTable().removeColumn(attractionsTable.getJTable().getColumnModel().getColumn(13));
            attractionsTable.getJTable().removeColumn(attractionsTable.getJTable().getColumnModel().getColumn(12));
            attractionsTable.getJTable().removeColumn(attractionsTable.getJTable().getColumnModel().getColumn(11));
            attractionsTable.getJTable().removeColumn(attractionsTable.getJTable().getColumnModel().getColumn(10));
            attractionsTable.getJTable().removeColumn(attractionsTable.getJTable().getColumnModel().getColumn(9));
            attractionsTable.getJTable().removeColumn(attractionsTable.getJTable().getColumnModel().getColumn(8));
            attractionsTable.getJTable().removeColumn(attractionsTable.getJTable().getColumnModel().getColumn(0));

            attractionsTable.getJTable().getColumnModel().getColumn(3).setMaxWidth(32);
            attractionsTable.getJTable().getColumnModel().getColumn(3).setMinWidth(32);
            
            attractionsTable.getJTable().getColumnModel().getColumn(2).setMaxWidth(85);
            attractionsTable.getJTable().getColumnModel().getColumn(2).setMinWidth(85);
            
            attractionsTable.getJTable().getColumnModel().getColumn(4).setMaxWidth(110);
            attractionsTable.getJTable().getColumnModel().getColumn(4).setMinWidth(110);
            
            attractionsTable.getJTable().getColumnModel().getColumn(5).setMaxWidth(100);
            attractionsTable.getJTable().getColumnModel().getColumn(5).setMinWidth(95);

            attractionsTable.getJTable().changeSelection(0, 0, false, false);
            attractionsTable.getJTable().repaint();
            attractionsTable.getJTable().revalidate();
        }
        if (pane != null) {
            remove(pane);
        }
        //Add PaidiaTable
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.PAGE_START;
        c.insets = new Insets(0, 2, 0, 0);
        c.weighty = 1.0;
        c.weightx = 0.0;
        c.gridwidth = 6;
        c.gridx = 0;
        c.gridy = 0;
        pane = new JScrollPane(attractionsTable.getJTable());
        add(pane, c);
        repaint();
        revalidate();

    }

    public void setFilters(String type, String cost, String participants, String openHours) {
        filterActivityType = type;
        filterCost = cost;
        filterParticipants = participants;
        filterOpenHours = openHours;
    }

    public void setClearanceLevel(int clear) {
        clearanceLevel = clear;
        if (clearanceLevel < 2) {
            removeButton.setEnabled(false);
        } else {
            removeButton.setEnabled(true);
        }
    }

}
