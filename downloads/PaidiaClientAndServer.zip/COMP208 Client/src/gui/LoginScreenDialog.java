package gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author Ben
 */
public class LoginScreenDialog extends JDialog {

    JTextField usernameTextBox;
    JPasswordField passwordTextBox;
    JLabel usernameLabel;
    JLabel passwordLabel;
    JButton submitButton;
    JButton exitButton;
    JFrame parent;

    public LoginScreenDialog(JFrame p) {
        super(p, true);
        setLayout(new GridBagLayout());
        parent = p;
        setSize(350, 200);
        setTitle("Login");
        setResizable(false);
        
        
        
        GridBagConstraints c = new GridBagConstraints();
        usernameLabel = new JLabel("Enter Username:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 0;
        add(usernameLabel, c);

        c = new GridBagConstraints();
        usernameTextBox = new JTextField();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 0;
        add(usernameTextBox, c);

        c = new GridBagConstraints();
        passwordLabel = new JLabel("Enter Password:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 1;
        add(passwordLabel, c);

        c = new GridBagConstraints();
        passwordTextBox = new JPasswordField();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 1;
        add(passwordTextBox, c);

        c = new GridBagConstraints();
        submitButton = new JButton("Login");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(20, 60, 0, 40);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 2;

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                submit();
            }
        });

        add(submitButton, c);

        c = new GridBagConstraints();
        exitButton = new JButton("Exit");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(20, 40, 0, 60);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 2;
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exitDialog();
            }
        });
        add(exitButton, c);
        
        this.getRootPane().setDefaultButton(submitButton);
        
    }

    void submit() {
        String inputUsername = usernameTextBox.getText();
        String inputPassword = passwordTextBox.getText();
        if(inputUsername.contains("'") || inputPassword.contains("'")){
            JOptionPane.showMessageDialog(LoginScreenDialog.this, "Please enter valid data.", "Invalid Input.", JOptionPane.ERROR_MESSAGE);
            return; // cancel submission
        }
        int clearance = PaidiaClient.login(inputUsername, inputPassword);    //TODO: MAKE LOGIN SERVER COMMAND RETURN CLEARANCE LEVEL. 0 FOR NO ACCESS.
        if (clearance > 0) {
            ManageAdminsPanel.setClearanceLevel(clearance);
            PaidiaClient.switchToAdmin(clearance);
            exitDialog();
        } else {
            JOptionPane.showMessageDialog(null, "Access Denied", "Incorrect username or password", JOptionPane.ERROR_MESSAGE);
        }
    }

    void exitDialog() {
        dispose();
    }
}
