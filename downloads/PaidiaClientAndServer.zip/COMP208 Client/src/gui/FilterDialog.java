package gui;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author Ben
 */
public class FilterDialog extends JDialog {

    JComboBox activityTypeCombo;
    JComboBox costCombo;
    JComboBox minParticipantsCombo;
    JComboBox openingHoursCombo;
    JCheckBox activityTypeCheckBox;
    JCheckBox costCheckBox;
    JCheckBox minParticipantsCheckBox;
    JCheckBox openingHoursCheckBox;
    JLabel activityTypeLabel;
    JLabel costLabel;
    JLabel minParticipantsLabel;
    JLabel openingHoursLabel;
    JButton submitButton;
    JButton exitButton;
    JFrame parent;
    String activePanel;
    String originalName;
    String[][] result;
    boolean isClient;

    public FilterDialog(JFrame p, boolean client, String filterActivityType, String filterCost, String filterParticipants, String filterOpenHours) {
        super(p, true);
        setLayout(new GridBagLayout());
        parent = p;
        setSize(500, 200);
        setResizable(false);
        setTitle("Filter");
        isClient = client;

        GridBagConstraints c = new GridBagConstraints();
        activityTypeLabel = new JLabel("Activity Type:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 0;
        add(activityTypeLabel, c);

        c = new GridBagConstraints();
        activityTypeCombo = new JComboBox();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(0, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 0;
        activityTypeCombo.addItem("Sights and Landmarks");
        activityTypeCombo.addItem("Museums");
        activityTypeCombo.addItem("Outdoor Activities");
        activityTypeCombo.addItem("Tours");
        activityTypeCombo.addItem("Shopping");
        activityTypeCombo.addItem("Fun and Games");
        activityTypeCombo.addItem("Water Sports");
        activityTypeCombo.addItem("Sports");
        activityTypeCombo.addItem("Theatre and Concerts");
        activityTypeCombo.addItem("Nature and Parks");
        activityTypeCombo.addItem("Spa and Wellness");
        if (!filterActivityType.equals("")) {
            activityTypeCombo.setSelectedItem(filterActivityType);
        }
        add(activityTypeCombo, c);

        c = new GridBagConstraints();
        costLabel = new JLabel("Cost:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 1;
        add(costLabel, c);

        c = new GridBagConstraints();
        costCombo = new JComboBox();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 1;
        costCombo.addItem("$");
        costCombo.addItem("$$");
        costCombo.addItem("$$$");
        if (!filterCost.equals("")) {
            costCombo.setSelectedItem(filterCost);
        }
        add(costCombo, c);

        c = new GridBagConstraints();
        minParticipantsLabel = new JLabel("Min. Participants:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 2;
        add(minParticipantsLabel, c);

        c = new GridBagConstraints();
        minParticipantsCombo = new JComboBox();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 2;
        minParticipantsCombo.addItem("1");
        minParticipantsCombo.addItem("2");
        minParticipantsCombo.addItem("3");
        minParticipantsCombo.addItem("4");
        minParticipantsCombo.addItem("5");
        minParticipantsCombo.addItem("6");
        minParticipantsCombo.addItem("7");
        minParticipantsCombo.addItem("8");
        minParticipantsCombo.addItem("9");
        if (!filterParticipants.equals("")) {
            minParticipantsCombo.setSelectedItem(filterParticipants);
        }
        add(minParticipantsCombo, c);

        c = new GridBagConstraints();
        openingHoursLabel = new JLabel("Opening Hours:");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 40, 0, 0);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 3;
        add(openingHoursLabel, c);

        c = new GridBagConstraints();
        openingHoursCombo = new JComboBox();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10, 10, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 3;
        openingHoursCombo.addItem("Day");
        openingHoursCombo.addItem("Night");
        if (!filterOpenHours.equals("")) {
            openingHoursCombo.setSelectedItem(filterOpenHours);
        }
        add(openingHoursCombo, c);

        c = new GridBagConstraints();
        submitButton = new JButton("Filter");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(20, 60, 0, 40);
        c.weightx = 0;
        c.gridx = 0;
        c.gridy = 4;
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                submit();
            }
        });
        add(submitButton, c);

        c = new GridBagConstraints();
        exitButton = new JButton("Exit");
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(20, 40, 0, 40);
        c.weightx = 0.5;
        c.gridx = 1;
        c.gridy = 4;
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exitDialog();
            }
        });
        add(exitButton, c);

        c = new GridBagConstraints();
        activityTypeCheckBox = new JCheckBox();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(5, 0, 0, 20);
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 0;
        if (!filterActivityType.equals("")) {
            activityTypeCheckBox.setSelected(true);
        }
        add(activityTypeCheckBox, c);

        c = new GridBagConstraints();
        costCheckBox = new JCheckBox();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(5, 0, 0, 20);
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 1;
        if (!filterCost.equals("")) {
            costCheckBox.setSelected(true);
        }
        add(costCheckBox, c);

        c = new GridBagConstraints();
        minParticipantsCheckBox = new JCheckBox();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(5, 0, 0, 20);
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 2;
        if (!filterParticipants.equals("")) {
            minParticipantsCheckBox.setSelected(true);
        }
        add(minParticipantsCheckBox, c);

        c = new GridBagConstraints();
        openingHoursCheckBox = new JCheckBox();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(5, 0, 0, 20);
        c.weightx = 0.5;
        c.gridx = 2;
        c.gridy = 3;
        if (!filterOpenHours.equals("")) {
            openingHoursCheckBox.setSelected(true);
        }
        add(openingHoursCheckBox, c);
    }

    void submit() {
        String type;
        String cost;
        String participants;
        String openHours;
        if (activityTypeCheckBox.isSelected() == false) {
            type = "";
        } else {
            type = activityTypeCombo.getSelectedItem().toString();
        }
        if (costCheckBox.isSelected() == false) {
            cost = "";
        } else {
            cost = costCombo.getSelectedItem().toString();
        }
        if (minParticipantsCheckBox.isSelected() == false) {
            participants = "";
        } else {
            participants = minParticipantsCombo.getSelectedItem().toString();
        }
        if (openingHoursCheckBox.isSelected() == false) {
            openHours = "";
        } else {
            openHours = openingHoursCombo.getSelectedItem().toString();
        }

        if (isClient == true) {
            PaidiaClient.existingAttractionsPanel.setFilters(type, cost, participants, openHours);
            PaidiaClient.existingAttractionsPanel.refresh();
        } else {
            PaidiaClient.existingAttractionsPanel2.setFilters(type, cost, participants, openHours);
            PaidiaClient.existingAttractionsPanel2.refresh();
        }
        dispose();
    }

    void exitDialog() {
        dispose();
    }
}
