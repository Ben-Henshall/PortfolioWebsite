//Nicholas Gibbon, 200964375, u3njg, sgngibbo
//Class to act as server for PAIDIA project

//import needed packages
import java.io.*;
import java.net.*;

public class ProtoServer {

    private static final int PORT_NUM = 12028; //data for port
    private static ServerSocket ss; //data for server socket
    private static boolean shutDownCalled = false; //boolean data for whether shut down is called

    //method to shut down the server
    public static void shutDown() {
        shutDownCalled = true; //sets variable for shut down to true.

        try {
            ss.close(); //trys to close server socket.
        } catch (Exception e) { //if exception occurs.
            System.exit(1); //exit
        }
    }

    //main method for server, accepts incoming requests from client and services them
    public static void main(String[] args) {
        
        ProtoSQLGen sg = new ProtoSQLGen(); //creates instance of ProtoSQLGen to be used.
        Socket incoming; // socket for an incoming request.
        Thread t; // Thread to be instantiated when a connection is made to the server.

        try {
            ss = new ServerSocket(PORT_NUM);// set up server on correct port.
            while (true) {
                incoming = ss.accept(); //accept incoming requests to the server. 
                t = new Thread(new Handler(incoming, sg)); //instantiate thread.
                t.start(); //start the thread
            }
        } catch (SocketException se) { //catch socket exceptions
            if (!shutDownCalled) {
                System.exit(1); //shut down server if shutdown called is true.
            }
        } catch (IOException ioe) {//if catch i/o exceptions.
            System.exit(1); //exit
        } finally { //finally ensure server closes cleanly.
            if (ss != null) {
                try {
                    ss.close();
                } catch (Exception e) {

                }
            }
        }
    }
}

//class for threads to access other resources stored with server
class Handler implements Runnable {

    private Socket client; //data to refer to client making request
    private ProtoSQLGen newSg; //data for sql generator class

    //constructor, set parameters to private data
    Handler(Socket s, ProtoSQLGen sg) {
        client = s;
        newSg = sg;
    }

    //run method where thread executes
    public void run() {
        //declare input and output feeds.
        BufferedReader in = null;
        PrintWriter out = null;
        String error = "'";
        try {
            //set i/o feeds
            in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            out = new PrintWriter(new OutputStreamWriter(client.getOutputStream()));
            System.out.println("Server connection established!");
            //temporary variables to use
            int id, cl, ap, minParticipants, intPersonReq, newCl;
            boolean done = false;
            String line, postcode, attractionName, description, activityType, 
                    cost, stringMinParticipants, openingHours, telephoneNo, 
                    email, website, address1, address2, townCity, county, 
                    username, password, stringid, stringcl, stringap,
                    stringType, stringCost, stringOpening, stringCounty, stringPersonReq,
                    newClString;
            //connection is closed by making done = true after each command is accepted or an error message produced. 
            while (!done) { //while done hasn't been called
                line = in.readLine();   // Read command
                
                switch(line.trim()){
                    case "0": //code for adding attraction.			
                        line = in.readLine();   // Read approved
                        stringap = line;
                        ap = Integer.parseInt(stringap);
                        
                        line = in.readLine();   // Read name
                        attractionName = line;

                        line = in.readLine();   // Read description
                        description = line;

                        line = in.readLine();   // Read activity type
                        activityType = line;

                        line = in.readLine();   // Read cost
                        cost = line;

                        line = in.readLine();   // Read min participants
                        stringMinParticipants = line;
                        minParticipants = Integer.parseInt(stringMinParticipants);
                        
                        line = in.readLine();   // Read opening hours
                        openingHours = line;

                        line = in.readLine();   // Read telephone number
                        telephoneNo = line;

                        line = in.readLine();   // Read email address
                        email = line;

                        line = in.readLine();   // Read website
                        website = line;

                        line = in.readLine();   // Read address 1
                        address1 = line;

                        line = in.readLine();   // Read address 2
                        address2 = line;

                        line = in.readLine();   // Read address 3
                        townCity = line;

                        line = in.readLine();   // Read county
                        county = line;

                        line = in.readLine();   // Read postcode
                        postcode = line;
                        
                        // Validated checked all at once to prevent further
                        // commands having ill effect
                        if(attractionName.contains(error) ||  description.contains(error) ||  
                                activityType.contains(error) ||  cost.contains(error) ||  
                                openingHours.contains(error) ||  telephoneNo.contains(error) ||  
                                email.contains(error) ||  website.contains(error) ||  
                                address1.contains(error) ||  address2.contains(error) ||  
                                townCity.contains(error) ||  county.contains(error) ||  
                                postcode.contains(error)){
                            out.print("2"); // Error code 2 = invalid input
                            break;
                        }

                        out.print(newSg.addAttraction(ap, attractionName, 
                                description, activityType, cost, minParticipants,
                                openingHours, telephoneNo, email, website, 
                                address1, address2, townCity, county, postcode));
                        
                        out.flush();
                        done = true;
                        break;
                    
                    case "1":    //code for getting approved attractions.
                        out.print(newSg.getApprovedAttractions());
                        out.flush();
                        done = true;
                        break;
                        
                    case "2": //code for getting suggestions
                        out.print(newSg.getSuggestions());
                        out.flush();
                        done = true;
                        break;
                        
                    case "3": //code for getting specific attraction details
                        line = in.readLine();      // Read id to show
                        stringid = line;
                        id = Integer.parseInt(stringid);
                        
                        out.print(newSg.getSpecificAttraction(id));
                        out.flush();
                        done = true;
                        break;
                        
                    case "4": //code for creating admin. 
                        line = in.readLine();   // Read username
                        username = line;
                        
                        line = in.readLine();   // Read password
                        password = line;
                        
                        line = in.readLine();   // Read clearance level
                        stringcl = line;
                        cl = Integer.parseInt(stringcl);
                        
                        if(username.contains(error)){
                            out.print("2"); // Error code 2 = invalid input
                            break;
                        }
                        
                        out.print(newSg.createAdmin(username, password, cl));
                        out.flush();
                        done = true;
                        break;
                        
                    case "5": //code for deleting activity.
                        line = in.readLine();   // Read id to delete
                        stringid = line;
                        id = Integer.parseInt(stringid);
                        
                        out.print(newSg.deleteAttraction(id));
                        out.flush();
                        done = true;
                        break;
                        
                    case "6": //code for logging in an admin.
                        line = in.readLine();   // Read username attempt
                        username = line;
                        
                        line = in.readLine();   // Read password attempt
                        password = line;
                        
                        if(username.contains(error)){
                            out.print("2"); // Error code 2 = invalid input
                            break;
                        }
                        
                        out.print(newSg.logIn(username, password));
                        out.flush();
                        done = true;
                        break;
                        
                    case "7": //code for promoting suggestion. 
                        line = in.readLine();   // Read id to promote
                        stringid = line;
                        id = Integer.parseInt(stringid);
                        
                        out.print(newSg.promoteSuggestion(id));
                        out.flush();
                        done = true;
                        break;
                        
                    case "8":   //get all admins
                        out.print(newSg.getAllAdmins());
                        out.flush();
                        done = true;
                        break;
                        
                    case "9":   //delete admin
                        line = in.readLine();   // Read id to delete
                        stringid = line;
                        id = Integer.parseInt(stringid);
                        
                        out.print(newSg.deleteAdmin(id));
                        out.flush();
                        done = true;
                        break;
                        
                    case "10":   //Get filtered (approved) attractions list
                        line = in.readLine();   // Read activity type filter
                        stringType = line;
                        
                        line = in.readLine();   // Read cost filter
                        stringCost = line;
                        
                        line = in.readLine();   // Read person requirements filter
                        stringPersonReq = line;
			if (stringPersonReq.equals("")) {
				intPersonReq = -1;
			} else {
                        	intPersonReq = Integer.parseInt(stringPersonReq);
                        }

                        line = in.readLine();   // Read opening hours filter
                        stringOpening = line;
                        
                        out.print(newSg.getFilteredAttractions(
                                stringType, stringCost, intPersonReq, stringOpening));
                        out.flush();
                        done = true;
                        break;
                        
                    case "11":   //Get specific admin
                        line = in.readLine();   // Read id to show
                        stringid = line;
                        id = Integer.parseInt(stringid);
                        
                        out.print(newSg.getSpecificAdmin(id));
                        out.flush();
                        done = true;
                        break;
                        
                    case "12":
                        line = in.readLine();   // Read id to show
                        stringid = line;
                        id = Integer.parseInt(stringid);
                        
                        line = in.readLine();   // Read new clearance level
                        newClString = line;
                        newCl = Integer.parseInt(newClString);
                        
                        out.print(newSg.editAdminClearanceLevel(id, newCl));
                        out.flush();
                        done = true;
                        break;
                        
                    case "13":
                        client.close();
                        out.close();
                        in.close();
                        break;
                }
            }
        } catch (IOException e) {

        } finally { //finally close connection neatly.
            try {
                in.close();
            } catch (IOException e) {

            }
            if (out != null) {
                out.close();
            }
            if (client != null) {
                try {
                    client.close();
                } catch (IOException e) {

                }
            }
        }
    }
    
    
} //end of file
