//Nicholas Gibbon, 200964375, u3njg, sgngibbo
//Class to hash password for PAIDIA project

public class ProtoHasher
{    
    
   	public ProtoHasher()
	{
         
	}
		
	public synchronized int hash(String pass)
	{
		int x; //variable to return end int result of hash
		int y = 0; //temporary int variable
		int c = (pass.length()); //int for length of the passed string
		char[] charArray = pass.toCharArray(); //char array of the passed string
		int[] intArray; //int array
		int i; //iterator int
		
		intArray = new int[c]; // set int array to be length of passed string
		
		for (i=0; i<c; i++)
		{ //for length of passed string
                    intArray[i] = (int)charArray[i];
		}
		
		//for each item in array, multiply by it's position(+1) and re-store
		for (i=0; i<c; i++)
		{			
			intArray[i] = intArray[i] * (i+1);	
		}
		
		//add all items in array together
		for (i=0; i<c; i++)
		{			
			y = y + intArray[i];
		}
		
		//multiply summation of array int by 9
		x = y *9;
		
		//return x
		return x;
	}
} //end of file