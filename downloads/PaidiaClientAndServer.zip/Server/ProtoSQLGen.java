//Class to act primarily as an sql generator, performing main legwork server side for PAIDIA project

import java.sql.*; //import important sql package

public class ProtoSQLGen {

    // JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/Paidia";

    //  Database credentials
    static final String USER = "root";
    static final String PASS = "password";

    final private static char ATT_SEP = 1;   // Separator for attributes
    final private static char ROW_SEP = 2;   // Separator for rows

    //constructor
    public ProtoSQLGen() {
        //~
    }

    
    
//---------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------	
    public synchronized int addAttraction(int approved, String name, String description, String typeOfActivity, String cost, int minPersonReq, String openingHours, String phoneNumber, String email, String website, String address1, String address2, String address3, String county, String postCode) {
        //declare connection and statement data to be used within method
        Connection conn = null;
        Statement stmt = null;

        //declare temporary variables to be used within method
        int id, newId = 0;
        int returnX = 0;

        try {
            Class.forName("com.mysql.jdbc.Driver"); //use jdbc driver
            conn = DriverManager.getConnection(DB_URL, USER, PASS); //make database connection

            stmt = conn.createStatement();
            String sql;

            //first query is used to find which id number to assign the new database entry
            sql = "SELECT Attraction_ID FROM tbl_Attraction;";
            System.out.println(sql);
            ResultSet rs = stmt.executeQuery(sql);

            if (!rs.isBeforeFirst()) {
                //do nothing because the result set is empty
            } else {
                rs.first();
                id = rs.getInt("Attraction_ID");
                if (id > newId) {
                    newId = id;
                }
            }

            while (rs.next()) {
                id = rs.getInt("Attraction_ID");
                if (id > newId) {
                    newId = id;
                }
            }

            newId = newId + 1; //at this point, id number to be used has been found and set

            sql = "INSERT INTO tbl_AttractionAddress VALUES (" + newId + ", '" + address1 + "', '" + address2 + "', '" + address3 + "', '" + county + "', '" + postCode + "');";
            stmt.executeUpdate(sql);

            sql = "INSERT INTO tbl_AttractionDetail VALUES (" + newId + ", '" + description + "', '" + typeOfActivity + "', '" + cost + "', " + minPersonReq + ", '" + openingHours + "', '" + phoneNumber + "', '" + email + "', '" + website + "');";
            stmt.executeUpdate(sql);

            //here queries are made to add the activity to the database in all of the relevant tables.
            sql = "INSERT INTO tbl_Attraction VALUES (" + newId + ", '" + name + "', " + approved + ", " + newId + ", " + newId + ");";
            stmt.executeUpdate(sql);

            returnX = 1; //at this point the return int is set to 1. if this point in the code is not reached then it will remain 0 indicating a none success.

            //once work has been done then close the connections neatly.
            rs.close();
            stmt.close();
            conn.close();
        } //code used to catch any exceptions if errors occur and the method can not operate as intended.
        catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException se2) {
                //~
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }

        System.out.println(returnX); //print at server	
        return returnX; //return for client
    }
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------

    
    
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------	
    public synchronized String getApprovedAttractions() {
        //declare connection and statement data to be used within method
        Connection conn = null;
        Statement stmt = null;

        //declare temporary variables to be used within method
        String returnData = "";

        try {
            Class.forName("com.mysql.jdbc.Driver"); //use jdbc driver
            conn = DriverManager.getConnection(DB_URL, USER, PASS); //make database connection

            stmt = conn.createStatement();
            String sql;

            //use query to retrieve all activity records which have been approved
            sql = "SELECT * FROM tbl_Attraction join tbl_AttractionDetail on tbl_Attraction.Attraction_ID=tbl_AttractionDetail.AttractionDetail_ID JOIN tbl_AttractionAddress on \n"
                    + "tbl_Attraction.Attraction_ID=tbl_AttractionAddress.AttractionAddress_ID" + " WHERE tbl_Attraction.Approved = 1;";

            ResultSet rs = stmt.executeQuery(sql);

            if (!rs.isBeforeFirst()) {
                //do nothing because the result set is empty
            } else {
                
                rs.first();
                returnData = returnData
                        + rs.getInt("Attraction_ID") + ATT_SEP
                        + rs.getString("TypeOfActivity") + ATT_SEP
                        + rs.getString("Cost") + ATT_SEP
                        + rs.getString("OpeningHours") + ATT_SEP
                        + rs.getInt("MinPersonReq") + ATT_SEP
                        + rs.getString("Name") + ATT_SEP
                        + rs.getString("Address1") + ATT_SEP
                        + rs.getString("Address2") + ATT_SEP
                        + rs.getString("Address3") + ATT_SEP
                        + rs.getString("County") + ATT_SEP
                        + rs.getString("PostCode") + ATT_SEP
                        + rs.getString("PhoneNumber") + ATT_SEP
                        + rs.getString("Website") + ATT_SEP
                        + rs.getString("Email") + ATT_SEP
                        + rs.getString("Description") + ATT_SEP
                        + rs.getInt("Approved") + ATT_SEP
                        + ROW_SEP;
            }

            while (rs.next()) {
                returnData = returnData
                        + rs.getInt("Attraction_ID") + ATT_SEP
                        + rs.getString("TypeOfActivity") + ATT_SEP
                        + rs.getString("Cost") + ATT_SEP
                        + rs.getString("OpeningHours") + ATT_SEP
                        + rs.getInt("MinPersonReq") + ATT_SEP
                        + rs.getString("Name") + ATT_SEP
                        + rs.getString("Address1") + ATT_SEP
                        + rs.getString("Address2") + ATT_SEP
                        + rs.getString("Address3") + ATT_SEP
                        + rs.getString("County") + ATT_SEP
                        + rs.getString("PostCode") + ATT_SEP
                        + rs.getString("PhoneNumber") + ATT_SEP
                        + rs.getString("Website") + ATT_SEP
                        + rs.getString("Email") + ATT_SEP
                        + rs.getString("Description") + ATT_SEP
                        + rs.getInt("Approved") + ATT_SEP
                        + ROW_SEP;
            }

            //once work has been done then close the connections neatly.
            rs.close();
            stmt.close();
            conn.close();
        } //code used to catch any exceptions if errors occur and the method can not operate as intended.
        catch (Exception se) {
            se.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException se2) {
                //~
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println(returnData); //output result to server locally for troubleshooting	
        return returnData;//return result for client
    }
//---------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------
    
    

//---------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------
    public synchronized String getSuggestions() {
        //declare connection and statement data to be used within method
        Connection conn = null;
        Statement stmt = null;

        //declare temporary variables to be used within method
        String returnData = "";

        try {
            Class.forName("com.mysql.jdbc.Driver"); //use jdbc driver
            conn = DriverManager.getConnection(DB_URL, USER, PASS); //make database connection

            stmt = conn.createStatement();
            String sql;

            //use query to retrieve all activity records which have been approved
            sql = "SELECT * FROM tbl_Attraction join tbl_AttractionDetail on tbl_Attraction.Attraction_ID=tbl_AttractionDetail.AttractionDetail_ID JOIN tbl_AttractionAddress on \n"
                    + "tbl_Attraction.Attraction_ID=tbl_AttractionAddress.AttractionAddress_ID" + " WHERE tbl_Attraction.Approved = 0;";

            ResultSet rs = stmt.executeQuery(sql);

            if (!rs.isBeforeFirst()) {
                //do nothing because the result set is empty
            } else {
                rs.first();
                returnData = returnData
                        + rs.getInt("Attraction_ID") + ATT_SEP
                        + rs.getString("TypeOfActivity") + ATT_SEP
                        + rs.getString("Cost") + ATT_SEP
                        + rs.getString("OpeningHours") + ATT_SEP
                        + rs.getInt("MinPersonReq") + ATT_SEP
                        + rs.getString("Name") + ATT_SEP
                        + rs.getString("Address1") + ATT_SEP
                        + rs.getString("Address2") + ATT_SEP
                        + rs.getString("Address3") + ATT_SEP
                        + rs.getString("County") + ATT_SEP
                        + rs.getString("PostCode") + ATT_SEP
                        + rs.getString("PhoneNumber") + ATT_SEP
                        + rs.getString("Website") + ATT_SEP
                        + rs.getString("Email") + ATT_SEP
                        + rs.getString("Description") + ATT_SEP
                        + rs.getInt("Approved") + ATT_SEP
                        + ROW_SEP;
            }

            while (rs.next()) {
                returnData = returnData
                        + rs.getInt("Attraction_ID") + ATT_SEP
                        + rs.getString("TypeOfActivity") + ATT_SEP
                        + rs.getString("Cost") + ATT_SEP
                        + rs.getString("OpeningHours") + ATT_SEP
                        + rs.getInt("MinPersonReq") + ATT_SEP
                        + rs.getString("Name") + ATT_SEP
                        + rs.getString("Address1") + ATT_SEP
                        + rs.getString("Address2") + ATT_SEP
                        + rs.getString("Address3") + ATT_SEP
                        + rs.getString("County") + ATT_SEP
                        + rs.getString("PostCode") + ATT_SEP
                        + rs.getString("PhoneNumber") + ATT_SEP
                        + rs.getString("Website") + ATT_SEP
                        + rs.getString("Email") + ATT_SEP
                        + rs.getString("Description") + ATT_SEP
                        + rs.getInt("Approved") + ATT_SEP
                        + ROW_SEP;
            }

            //once work has been done then close the connections neatly.
            rs.close();
            stmt.close();
            conn.close();
        } //code used to catch any exceptions if errors occur and the method can not operate as intended.
        catch (Exception se) {
            se.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException se2) {
                //~
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println(returnData); //output result to server locally for troubleshooting	
        return returnData;//return result for client
    }
//---------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------    
  
    
//---------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------
    public synchronized String getSpecificAttraction(int id) {
        //declare connection and statement data to be used within method
        Connection conn = null;
        Statement stmt = null;

        //declare temporary variables to be used within method
        String returnData = "";

        try {
            Class.forName("com.mysql.jdbc.Driver"); //use jdbc driver
            conn = DriverManager.getConnection(DB_URL, USER, PASS); //make database connection

            stmt = conn.createStatement();
            String sql;

            //use query to retrieve all activity records which have been approved
            sql = "SELECT * FROM tbl_Attraction join tbl_AttractionDetail on tbl_Attraction.Attraction_ID=tbl_AttractionDetail.AttractionDetail_ID JOIN tbl_AttractionAddress on \n"
                    + "tbl_Attraction.Attraction_ID=tbl_AttractionAddress.AttractionAddress_ID" + " WHERE tbl_Attraction.Attraction_ID = " + id + ";";

            ResultSet rs = stmt.executeQuery(sql);

            if (!rs.isBeforeFirst()) {
                //do nothing because the result set is empty
            } else {
                rs.first();
                returnData = returnData
                        + rs.getInt("Attraction_ID") + ATT_SEP
                        + rs.getString("TypeOfActivity") + ATT_SEP
                        + rs.getString("Cost") + ATT_SEP
                        + rs.getString("OpeningHours") + ATT_SEP
                        + rs.getInt("MinPersonReq") + ATT_SEP
                        + rs.getString("Name") + ATT_SEP
                        + rs.getString("Address1") + ATT_SEP
                        + rs.getString("Address2") + ATT_SEP
                        + rs.getString("Address3") + ATT_SEP
                        + rs.getString("County") + ATT_SEP
                        + rs.getString("PostCode") + ATT_SEP
                        + rs.getString("PhoneNumber") + ATT_SEP
                        + rs.getString("Website") + ATT_SEP
                        + rs.getString("Email") + ATT_SEP
                        + rs.getString("Description") + ATT_SEP
                        + rs.getInt("Approved") + ATT_SEP
                        + ROW_SEP;
            }

            //once work has been done then close the connections neatly.
            rs.close();
            stmt.close();
            conn.close();
        } //code used to catch any exceptions if errors occur and the method can not operate as intended.
        catch (Exception se) {
            se.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException se2) {
                //~
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println(returnData); //output result to server locally for troubleshooting	
        return returnData;//return result for client
    }
//---------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------   
    
    
   
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
    public synchronized int createAdmin(String username, String password, int cl) {

        //declare connection and statement data to be used within method
        Connection conn = null;
        Statement stmt = null;

        //declare temporary variables to be used within method
        int returnX = 0, newId = 0, found = 0;
        int id, passint;
        String thisusername;
        ProtoHasher newProtoHasher = new ProtoHasher();

        try {
            Class.forName("com.mysql.jdbc.Driver"); //use jdbc driver
            conn = DriverManager.getConnection(DB_URL, USER, PASS); //make database connection

            stmt = conn.createStatement();
            String sql;

            //make query to return all from admin so we can search for a duplicate of the passed username
            sql = "SELECT * FROM Admin;";

            ResultSet rs = stmt.executeQuery(sql);

            if (!rs.isBeforeFirst()) {
                //result set empty
            } else {
                rs.first();
                thisusername = rs.getString("username");

                if (username.equals(thisusername)) {
                    found = 1;
                }
            }

            while (rs.next()) {
                thisusername = rs.getString("username");

                if (username.equals(thisusername)) {
                    found = 1;
                }
            }

            //if the username is not already in the admin table
            if (found == 0) {
                //retrieve all records from the admin table to find how to make new id number to add for new record
                sql = "SELECT * FROM Admin;";
                rs = stmt.executeQuery(sql);

                while (rs.next()) {
                    id = rs.getInt("Admin_ID");

                    if (id > newId) {
                        newId = id;
                    }
                }

                newId = newId + 1;
                passint = newProtoHasher.hash(password);

                //insert into admin table the new username and password combo
                sql = "INSERT INTO Admin VALUES (" + newId + ", '" + username + "', " + passint + ", " + cl + ");";
                stmt.executeUpdate(sql);

                returnX = 1;
            }

            //once work has been done then close the connections neatly.
            rs.close();
            stmt.close();
            conn.close();
        } //code used to catch any exceptions if errors occur and the method can not operate as intended.
        catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException se2) {
                //~
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println(returnX);
        return returnX;
    }
//---------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------    

    
//---------------------------------------------------------------------------------------	
//---------------------------------------------------------------------------------------
    public synchronized int deleteAttraction(int id) {
        //declare connection and statement data to be used within method
        Connection conn = null;
        Statement stmt = null;

        //declare temporary variables to be used within method	
        int returnX = 0;

        try {
            Class.forName("com.mysql.jdbc.Driver"); //use jdbc driver
            conn = DriverManager.getConnection(DB_URL, USER, PASS); //make database connection

            stmt = conn.createStatement();
            String sql;

            // create and perform queries to systematically remove all traces of an activity from the database given the passed id number
            sql = "DELETE FROM tbl_Attraction " + "WHERE Attraction_ID = " + id + ";";
            stmt.executeUpdate(sql);
            
            sql = "DELETE FROM tbl_AttractionAddress " + "WHERE AttractionAddress_ID = " + id + ";";
            stmt.executeUpdate(sql);

            sql = "DELETE FROM tbl_AttractionDetail " + "WHERE AttractionDetail_ID = " + id + ";";
            stmt.executeUpdate(sql);

            returnX = 1;

            //once work has been done then close the connections neatly.
            //rs.close();
            stmt.close();
            conn.close();
        } //code used to catch any exceptions if errors occur and the method can not operate as intended.
        catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException se2) {
                //~
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println(returnX); //print at server	
        return returnX;	//return for client
    }
//--------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------
    
    
    
//--------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------
    public synchronized int logIn(String username, String password) {
        //declare connection and statement data to be used within method
        Connection conn = null;
        Statement stmt = null;

        //declare temporary variables to be used within method	
        ProtoHasher newProtoHasher = new ProtoHasher();
        int passint = newProtoHasher.hash(password);
        int returnX = 0;

        try {
            Class.forName("com.mysql.jdbc.Driver"); //use jdbc driver
            conn = DriverManager.getConnection(DB_URL, USER, PASS); //make database connection

            stmt = conn.createStatement();
            String sql;

            //query if the admin table contains a matching username and password as passed to method in arguments
            sql = "SELECT * FROM Admin WHERE username='" + username + "' AND password =" + passint + ";";

            ResultSet rs = stmt.executeQuery(sql);

            if (!rs.isBeforeFirst()) {
                //result set has no results
                returnX = 0;    // Login failed
            } else {
                rs.first();
                returnX = rs.getInt("ClearanceLevel");    // login succeed, extract clearance level
            }

            //once work has been done then close the connections neatly.
            rs.close();
            stmt.close();
            conn.close();
        } //code used to catch any exceptions if errors occur and the method can not operate as intended.
        catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException se2) {
                //~
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println(returnX); //print at server
        return returnX; //return for client
    }
//--------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------

    
//---------------------------------------------------------------------------------------	
//---------------------------------------------------------------------------------------
    public synchronized int promoteSuggestion(int id) {
        //declare connection and statement data to be used within method
        Connection conn = null;
        Statement stmt = null;

        //declare temporary variables to be used within method	
        int returnX = 0;

        try {
            Class.forName("com.mysql.jdbc.Driver"); //use jdbc driver
            conn = DriverManager.getConnection(DB_URL, USER, PASS); //make database connection

            stmt = conn.createStatement();
            String sql;

            // query to approve suggestion given passed id 
            sql = "UPDATE tbl_Attraction SET Approved=1 WHERE Attraction_ID = " + id + ";";
            stmt.executeUpdate(sql);

            returnX = 1;

            //once work has been done then close the connections neatly.
            //rs.close();
            stmt.close();
            conn.close();
        } //code used to catch any exceptions if errors occur and the method can not operate as intended.
        catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException se2) {
                //~
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println(returnX); //print at server	
        return returnX;	//return for client
    }
//--------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------		
    
    
    
//---------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------
        public synchronized String getAllAdmins() {
        //declare connection and statement data to be used within method
        Connection conn = null;
        Statement stmt = null;

        //declare temporary variables to be used within method
        String returnData = "";

        try {
            Class.forName("com.mysql.jdbc.Driver"); //use jdbc driver
            conn = DriverManager.getConnection(DB_URL, USER, PASS); //make database connection

            stmt = conn.createStatement();
            String sql;

            //use query to retrieve all activity records which have been approved
            sql = "SELECT * FROM Admin;";

            ResultSet rs = stmt.executeQuery(sql);

            if (!rs.isBeforeFirst()) {
                //do nothing because the result set is empty
            } else {
                rs.first();
                returnData = returnData
                        + rs.getInt("Admin_ID") + ATT_SEP
                        + rs.getString("Username") + ATT_SEP
                        + rs.getInt("ClearanceLevel") + ATT_SEP
                        + ROW_SEP;
            }

            while (rs.next()) {
                returnData = returnData
                        + rs.getInt("Admin_ID") + ATT_SEP
                        + rs.getString("Username") + ATT_SEP
                        + rs.getInt("ClearanceLevel") + ATT_SEP
                        + ROW_SEP;
            }

            //once work has been done then close the connections neatly.
            rs.close();
            stmt.close();
            conn.close();
        } //code used to catch any exceptions if errors occur and the method can not operate as intended.
        catch (Exception se) {
            se.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException se2) {
                //~
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println(returnData); //output result to server locally for troubleshooting	
        return returnData;//return result for client
    }
//---------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------- 
    
    
//---------------------------------------------------------------------------------------	
//---------------------------------------------------------------------------------------
    public synchronized int deleteAdmin(int id) {
        //declare connection and statement data to be used within method
        Connection conn = null;
        Statement stmt = null;

        //declare temporary variables to be used within method	
        int returnX = 0;

        try {
            Class.forName("com.mysql.jdbc.Driver"); //use jdbc driver
            conn = DriverManager.getConnection(DB_URL, USER, PASS); //make database connection

            stmt = conn.createStatement();
            String sql;

            // create and perform queries to systematically remove all traces of an activity from the database given the passed id number
            sql = "DELETE FROM Admin " + "WHERE Admin_ID = " + id + ";";
            stmt.executeUpdate(sql);

            returnX = 1;

            //once work has been done then close the connections neatly.
            //rs.close();
            stmt.close();
            conn.close();
        } //code used to catch any exceptions if errors occur and the method can not operate as intended.
        catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException se2) {
                //~
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println(returnX); //print at server	
        return returnX;	//return for client
    }
//--------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------
 
        
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------	
    public synchronized String getFilteredAttractions(String inputType, String inputCost, 
            int inputPersonReq, String inputOpeningH) {
        //declare connection and statement data to be used within method
        Connection conn = null;
        Statement stmt = null;

        //declare temporary variables to be used within method
        String returnData = "";

        try {
            Class.forName("com.mysql.jdbc.Driver"); //use jdbc driver
            conn = DriverManager.getConnection(DB_URL, USER, PASS); //make database connection

            stmt = conn.createStatement();
            String sql;

            //use query to retrieve all activity records which have been approved
            sql = "SELECT * FROM tbl_Attraction join tbl_AttractionDetail on tbl_Attraction.Attraction_ID=tbl_AttractionDetail.AttractionDetail_ID JOIN tbl_AttractionAddress on \n"
                    + "tbl_Attraction.Attraction_ID=tbl_AttractionAddress.AttractionAddress_ID" + " WHERE tbl_Attraction.Approved = 1";

            
            if(!inputType.equals("")){
                sql = sql + " AND tbl_AttractionDetail.TypeOfActivity = '" + inputType + "'";
            }
            
            if(!inputCost.equals("")){
                sql = sql + " AND tbl_AttractionDetail.Cost = '" + inputCost + "'";
            }
            
            if(inputPersonReq > 0){
                sql = sql + " AND tbl_AttractionDetail.MinPersonReq <= " + inputPersonReq;
            }
  
            if(!inputOpeningH.equals("")){
                sql = sql + " AND tbl_AttractionDetail.OpeningHours = '" + inputOpeningH + "'";
            }
            
            sql = sql + ";";    // Terminate statement
            
            ResultSet rs = stmt.executeQuery(sql);

            if (!rs.isBeforeFirst()) {
                //do nothing because the result set is empty
            } else {
                rs.first();
                returnData = returnData
                        + rs.getInt("Attraction_ID") + ATT_SEP
                        + rs.getString("TypeOfActivity") + ATT_SEP
                        + rs.getString("Cost") + ATT_SEP
                        + rs.getString("OpeningHours") + ATT_SEP
                        + rs.getInt("MinPersonReq") + ATT_SEP
                        + rs.getString("Name") + ATT_SEP
                        + rs.getString("Address1") + ATT_SEP
                        + rs.getString("Address2") + ATT_SEP
                        + rs.getString("Address3") + ATT_SEP
                        + rs.getString("County") + ATT_SEP
                        + rs.getString("PostCode") + ATT_SEP
                        + rs.getString("PhoneNumber") + ATT_SEP
                        + rs.getString("Website") + ATT_SEP
                        + rs.getString("Email") + ATT_SEP
                        + rs.getString("Description") + ATT_SEP
                        + rs.getInt("Approved") + ATT_SEP
                        + ROW_SEP;
            }

            while (rs.next()) {
                returnData = returnData
                        + rs.getInt("Attraction_ID") + ATT_SEP
                        + rs.getString("TypeOfActivity") + ATT_SEP
                        + rs.getString("Cost") + ATT_SEP
                        + rs.getString("OpeningHours") + ATT_SEP
                        + rs.getInt("MinPersonReq") + ATT_SEP
                        + rs.getString("Name") + ATT_SEP
                        + rs.getString("Address1") + ATT_SEP
                        + rs.getString("Address2") + ATT_SEP
                        + rs.getString("Address3") + ATT_SEP
                        + rs.getString("County") + ATT_SEP
                        + rs.getString("PostCode") + ATT_SEP
                        + rs.getString("PhoneNumber") + ATT_SEP
                        + rs.getString("Website") + ATT_SEP
                        + rs.getString("Email") + ATT_SEP
                        + rs.getString("Description") + ATT_SEP
                        + rs.getInt("Approved") + ATT_SEP
                        + ROW_SEP;
            }

            //once work has been done then close the connections neatly.
            rs.close();
            stmt.close();
            conn.close();
        } //code used to catch any exceptions if errors occur and the method can not operate as intended.
        catch (Exception se) {
            se.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException se2) {
                //~
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println(returnData); //output result to server locally for troubleshooting	
        return returnData;//return result for client
    }

//---------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------      
        

    
    //---------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------
    public synchronized String getSpecificAdmin(int id) {
        //declare connection and statement data to be used within method
        Connection conn = null;
        Statement stmt = null;

        //declare temporary variables to be used within method
        String returnData = "";

        try {
            Class.forName("com.mysql.jdbc.Driver"); //use jdbc driver
            conn = DriverManager.getConnection(DB_URL, USER, PASS); //make database connection

            stmt = conn.createStatement();
            String sql;

            //use query to retrieve all activity records which have been approved
            sql = "SELECT * FROM Admin" + " WHERE Admin_ID = " + id + ";";

            ResultSet rs = stmt.executeQuery(sql);

            if (!rs.isBeforeFirst()) {
                //do nothing because the result set is empty
            } else {
                rs.first();
                returnData = returnData
                        + rs.getInt("Admin_ID") + ATT_SEP
                        + rs.getString("Username") + ATT_SEP
                        + rs.getString("Password") + ATT_SEP
                        + rs.getInt("ClearanceLevel") + ATT_SEP
                        + ROW_SEP;
            }

            //once work has been done then close the connections neatly.
            rs.close();
            stmt.close();
            conn.close();
        } //code used to catch any exceptions if errors occur and the method can not operate as intended.
        catch (Exception se) {
            se.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException se2) {
                //~
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println(returnData); //output result to server locally for troubleshooting	
        return returnData;//return result for client
    }
//---------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------   
    
    
//---------------------------------------------------------------------------------------	
//---------------------------------------------------------------------------------------
    public synchronized int editAdminClearanceLevel(int id, int cl) {
        //declare connection and statement data to be used within method
        Connection conn = null;
        Statement stmt = null;

        //declare temporary variables to be used within method
        int returnX = 0;

        try {
            Class.forName("com.mysql.jdbc.Driver"); //use jdbc driver
            conn = DriverManager.getConnection(DB_URL, USER, PASS); //make database connection

            stmt = conn.createStatement();
            String sql;

            // query to approve suggestion given passed id 
            sql = "UPDATE Admin SET ClearanceLevel = " + cl + " WHERE Admin_ID = " + id + ";";
            stmt.executeUpdate(sql);

            returnX = 1;

            //once work has been done then close the connections neatly.
            //rs.close();
            stmt.close();
            conn.close();
        } //code used to catch any exceptions if errors occur and the method can not operate as intended.
        catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
            } catch (SQLException se2) {
                //~
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println(returnX); //print at server	
        return returnX;	//return for client
    }
//--------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------
    
    
    
    
}//end of file
